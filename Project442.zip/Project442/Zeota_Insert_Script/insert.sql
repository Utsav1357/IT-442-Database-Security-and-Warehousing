--Branch_input
insert into BRANCH values(	100,'3415 Olanwood Court Suite 202','MANKATO','MN',5,56001);					
insert into BRANCH values(	101,'307 W. Allegheny Avenue','SAINT PAUL','MN',55101,5);					
insert into BRANCH values(	102,'145 Laywers Row','ROCHESTER','MN',55901,5);					
insert into BRANCH values(	103,'1717 Arch Street','SPRINGFIELD','IL',62701,5);					
insert into BRANCH values(	104,'200 Pennsylvania, Suite 200','WASHINGTON','DC',20009,6);					
insert into BRANCH values(	105,'14714 Main Street','DOVER','DE',19901,6);					
insert into BRANCH values(	106,'13 Federal Street P.O Box 704','TALLAHASSEE','FL',32301,6);					
insert into BRANCH values(	107,'1300 N Lake Shore Dr.','HONOLULU','HI',96813,1);					
insert into BRANCH values(	108,'warren','JUNEAU','AK',99801,2);					
insert into BRANCH values(	109,'San Street','SACRAMENTO','CA',95814,3);					
insert into BRANCH values(	110,'Stewart Sreet','CARSON CITY','NV',89701,3);					
insert into BRANCH values(	111,'1050 Conn. Ave','SALEM','OR',97301,3);					
insert into BRANCH values(	112,'300 Virginia Ave, Suite 300','PHOENIX','AZ',85003,4);					
--product
insert into product values(	110,'Microsoft','Xbox Set','Xbox,2 controller, 1 Mario game,2 memory cards',400,275,'Game',0,0,0,0,'		',0);
insert into product values(	120,'Microsoft','Xbox','Xbox',200,150,'Game',-202,30,20,0,'		',0);
insert into product values(	130,'Microsoft','Controller','Xbox controller',55,25,'Game',-308,60,40,0,'		',0);
insert into product values(	140,'Samsung','Memory Card','Xbox Memeory Card',50,25,'Game',-326,50,35,0,'		',0);
insert into product values(	150,'Sony','Mario Game','Mario Game for Xbox',50,25,'Game',-163,35,20,0,'	29-Apr-00	',0);
insert into product values(	160,'Sony','TV','42 inch Plasma TV',4995,4000,'Entertainment',5,3,5,0,'		',0);
insert into product values(	170,'Samsung','TV','42 inch Plasma TV',4495,3000,'Entertainment',5,3,5,0,'		',0);
insert into product values(	180,'Microsoft','Office','Office Professional Edition 2003',125,50,'Software',20,8,25,0,'		',0);
insert into product values(	190,'Microsoft','Windows','Windows XP Professional Edition',75,25,'Software',20,8,25,0,'		',0);
insert into product values(	200,'Microsoft','Data Input','Optical Desktop with Fingerprint Reader',50,20,'Hardware',50,20,60,0,'		',0);
--regions

insert into regions values(	1,'Hawaiian')
insert into regions values(	2,'Alaskan');
insert into regions values(	3,'Pacific');
insert into regions values(	4,'Mountain');
insert into regions values(	5,'Central');
insert into regions values(	6,'Eastern');
-- vendor

insert into vendor values(	1000,'Samsung','21 Roscoe Dr','Rochester','MN',52010,5096312121);
insert into vendor values(	1001,'Sony','109 Shepard Dr','Madison','WI',68012,3022412121);
insert into vendor values(	1002,'Microsoft','310 Simpson Ave','New York','NY',78012,6312412121);


--promotion

insert into promotion values(	100,'Xbox_2 controller_PROMOTION');
insert into promotion values(	101,'Xbox_PROMOTION');
insert into promotion values(	102,'Xbox controller_PROMOTION');
insert into promotion values(	103,'Xbox Memeory Card_PROMOTION');
insert into promotion values(	104,'Mario Game for Xbox_PROMOTION');
insert into promotion values(	105,'42 inch Plasma TV_PROMOTION');

--warehouse
insert into warehouse values(	1100,'Samsung','21 Roscoe Dr','Rochester','MN',52010,5096312121);
insert into warehouse values(	1110,'Sony','109 Shepard Dr','Madison','WI',68012,3022412121);
insert into warehouse values(	1120,'Microsoft','310 Simpson Ave','New York','NY',78012,6312412121);

--ship method
insert into Ship_Method values(	1,'ground-air');
insert into Ship_Method values(	2,'Ground');
insert into Ship_Method values(	3,'1day-air');
insert into Ship_Method values(	4,'1day');
insert into Ship_Method values(	5,'2day-air');
insert into Ship_Method values(	6,'2day');
insert into Ship_Method values(	7,'1-day');
insert into Ship_Method values(	8,'2-day');



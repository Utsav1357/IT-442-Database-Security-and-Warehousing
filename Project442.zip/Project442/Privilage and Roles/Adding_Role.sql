--role to the user
USE [Zeota]
GO
ALTER ROLE [Manager] ADD MEMBER [SWYATT1]
GO
USE [Zeota]
GO
ALTER ROLE [Manager] ADD MEMBER [WAl1]
GO
USE [Zeota]
GO
ALTER ROLE [Manager] ADD MEMBER [WAlbert1]
GO
USE [Zeota]
GO
ALTER ROLE [Manager] ADD MEMBER [WDonald1]
GO


--STAFF
USE [Zeota]
GO
ALTER ROLE [Staff] ADD MEMBER [SJamesF1]
GO
USE [Zeota]
GO
ALTER ROLE [Staff] ADD MEMBER [WBruce1]
GO
USE [Zeota]
GO
ALTER ROLE [Staff] ADD MEMBER [WAlbert1]
GO
USE [Zeota]
GO
ALTER ROLE [Staff] ADD MEMBER [WJames1]

GO


--ADDING ROLESuse [Zeota]
GO
GRANT DELETE ON [dbo].[Department] TO [Staff]
GO
use [Zeota]
GO
GRANT INSERT ON [dbo].[Department] TO [Staff]
GO
use [Zeota]
GO
GRANT SELECT ON [dbo].[Department] TO [Staff]
GO
use [Zeota]
GO
GRANT UPDATE ON [dbo].[Department] TO [Staff]
GO

--manager read only
USE [Zeota]
GO
CREATE ROLE [Manager] AUTHORIZATION [db_datareader]
GO
USE [Zeota]
GO
ALTER AUTHORIZATION ON SCHEMA::[db_datareader] TO [Manager]
GO




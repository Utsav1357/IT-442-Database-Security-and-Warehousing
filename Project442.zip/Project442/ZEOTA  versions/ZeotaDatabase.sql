create table VENDOR (
	VENDOR_NO int not null,
	NAME VARCHAR(50) null,
        STREET VARCHAR(30),
        CITY VARCHAR(12),
        STATE CHAR(2),
        ZIP int,
	TEL_NO VARCHAR(12) null, 
	constraint VENDOR_PK primary key (VENDOR_NO) ) ;


create table PRODUCT (
	PRODUCT_NO int not null,
	BRAND VARCHAR(15) null,
	CLASS VARCHAR(20) null,
	PRODUCT_DESCRIPTION VARCHAR(50) null,
	UNIT_PRICE int null,
	UNIT_COST int null,
	PRODUCT_CATEGORY VARCHAR(15) null,
	QOH int null,
	ORDER_LEVEL int null,
	ORDER_QTY int null,
	BACK_ORDER int null,
	AVAIL_DATE varchar(15) null,
	DAMAGED_QTY int null, 
	constraint PRODUCT_PRODUCTNO_PK primary key (PRODUCT_NO) ); 


create table PROMOTION (
	PROMOTION_NO int,
	promotion_name int,
	constraint P_PROMOTION_NO_PK primary key (PROMOTION_NO) ); 


create table Warehouse(
	warehouse_no int,
	name varchar(50),
	street varchar(30),
	city varchar(12),
	state varchar(2),
	zip int,
	TEL_NO varchar(12),
	constraint w_warehouse_no_PK primary key (warehouse_no));

CREATE TABLE ship_method(
Ship_Method_NO int,
Mthod_name varchar(30),
constraint ship_method_Ship_Method_NO_PK primary key (Ship_Method_NO));



create table return_category(
	return_code int,
	description varchar(40),
	constraint return_category_return_code_PK primary key (return_code));

create table INQUIRY_Category (
	Cat_ID varchar(20),
	category varchar(50),
	constraint INQUIRY_Category_ID_PK primary key (Cat_ID)); 


create table regions(
	region_no int,
	timezone varchar(40),
	constraint regions_region_no_PK primary key (region_no));

create table BRANCH (
	BRANCH_NO int not null,
	STREET VARCHAR(30) null,
	CITY VARCHAR(15) not null,
	STATE VARCHAR(2) ,
        REGION_NO int,
	ZIP int null constraint BRANCH_ZIP_CHK check ( ZIP > 0 ) , 
	constraint BRANCH_BRANCHNO_PK primary key (BRANCH_NO) );

create table List_Tables(
	Table_ID int,
	Table_Name varchar(30),
	constraint List_Tables_Table_ID primary key (Table_ID));


create table Training(
		 Train_NO int,
		 Training_name varchar(30),
		 CONSTRAINT Training_Emp_NO_FK PRIMARY KEY (Train_NO));

create table Company(
	Comp_NO int,
	Comp_name varchar(30),
	Phone# varchar(30),
	StAddress varchar(30),
	city varchar(30),
	ZIP int,
	State varchar(2),
	CONSTRAINT C_Comp_NO_pk primary key (Comp_NO));

create table Certificate(
		Cert_NO int,
		Cert_name varchar(30),
		CONSTRAINT C_start_date_pk primary key (Cert_NO));

create table Roles(
		Role_ID int,
		Role_name varchar(30),
		CONSTRAINT Roles_Role_ID_pk primary key (Role_ID));

create table Institution(
         Inst_NO int, 
         Institute_name varchar(30),
	 city varchar(30),
	 state varchar(2),
	 CONSTRAINT I_Inst_NO_pk primary key (Inst_NO));


create table Skill(
		 Skill_NO int,
		 Skill_name varchar(30),
		 CONSTRAINT S_Skill_NO_pk primary key (Skill_NO));



create table Minor(
		 Minor_NO int,
		 Minor_name varchar(30),
		 CONSTRAINT Minor_Minor_NO_pk primary key (Minor_NO));

create table Major(
         Major_NO int, 
         Major_name varchar(30),
		 CONSTRAINT M_Major_NO_pk primary key (Major_NO));

create table Education_Type(
         Edu_Type_No int, 
         Type_name varchar(30),
	 CONSTRAINT E_Edu_Type_No_pk primary key (Edu_Type_No));



create table employement_status (
         status_no int not null , 
         description varchar(40) ,
         CONSTRAINT employee_status_pk primary key (status_no));

create table position (
        position_NO int not null , 
        description varchar(40) ,
    CONSTRAINT employee_position_pk  primary key (position_NO));

create table payroll (
	payroll_NO int,
	start_date date,
   	end_date date, 
	CONSTRAINT EP_payroll_NO_PK primary KEY (payroll_NO)) ;


create table Prod_Condition(
	Cond_NO int,
	Cond_Name varchar(30),
	CONSTRAINT Prod_Condition_Cond_NO_PK primary KEY (Cond_NO)) ;



create table Branch_Size(
	BS_NO int,
	Name varchar(40),
	CONSTRAINT Branch_Size_BS_NO_PK primary KEY (BS_NO)) ;


create table Relationship(
	Rel_Type int,
	Rel_Name varchar(40),
	CONSTRAINT Relationship_Rel_Type_PK primary KEY (Rel_Type)) ;

create table Department (
         Dept_NO int, 
         Dept_name varchar(30) ,
		 street  varchar(40),
		 city varchar(15),
		 state varchar(2),
		 zip int,
         CONSTRAINT D_Dept_NO_pk primary key (Dept_NO));



/*--------------SECOND------------------*/


create table Return2Vendor(
	Return_Date int not null,
	VENDOR_NO int,
        PRODUCT_NO int,
        QTY int,
        V_Confirmation_No VARCHAR(4),
        Amount int,
	constraint Return_Date_PK primary key (Return_Date),
	CONSTRAINT PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO),
	CONSTRAINT VENDOR_NO_FK FOREIGN KEY (VENDOR_NO) REFERENCES VENDOR (VENDOR_NO)) ;


create table Vndor_PROMOTION (
	VPID int,
	V_Price int,
	START_DATE date,
	END_DATE date,
	Vendor_no int,
	promo_no int,
	constraint Vndor_PROMOTION_VPID_PK primary key (VPID),
	CONSTRAINT Vndor_PROMOTION_PROMO_NO_FK FOREIGN KEY (promo_no) REFERENCES Promotion (PROMOTION_NO),
	CONSTRAINT Vndor_PROMOTION_Vendor_no_FK FOREIGN KEY (vendor_no) REFERENCES Vendor (vendor_no)); 



create table Prod_Promotion (
	ppid int,
	p_price int,
	start_date date,
	end_date date,
	product_no int,
	PROMO_ID int,
	constraint Prod_Promotion_PPID_PK primary key (PPID),
	CONSTRAINT Prod_Promotion_product_NO_FK FOREIGN KEY (product_NO) REFERENCES product (product_NO),
	CONSTRAINT Prod_Promotion_PROMO_ID_FK FOREIGN KEY (PROMO_ID) REFERENCES Promotion (PROMOTION_NO)); 


create table VENDORPRICE (
	VPRICE_NO int not null,
	VENDOR_NO int not null,
	PRODUCT_NO int not null,
	VPRICE int not null,
	DISCOUNT VARCHAR(4) null,
	constraint VENDORPRICE_PK primary key (VPRICE_NO),
	CONSTRAINT VENDORPRICE_product_NO_FK FOREIGN KEY (product_NO) REFERENCES product (product_NO),
	CONSTRAINT VENDORPRICE_Vendor_no_FK FOREIGN KEY (vendor_no) REFERENCES Vendor (vendor_no)); 

create table Vendor_QTYDISCOUNT (
	QTYDISCOUNT_NO int not null,
	D_PRICE int null,
	MIN_QTY int null,
	MAX_QTY CHAR(10) null,
	VENDOR_NO int null,
	constraint QTYDISCOUNT_PK primary key (QTYDISCOUNT_NO),
	CONSTRAINT VQ_VENDOR_NO_FK FOREIGN KEY (VENDOR_NO) REFERENCES VENDOR (VENDOR_NO)); 

create table QTYDISCOUNT (
	QTYDISCOUNT_NO int not null,
	D_PRICE int null,
	MIN_QTY int null,
	MAX_QTY CHAR(10) null,
	PRODUCT_NO int null,
	constraint QTYDISCOUNT_QTYDISCOUNT_NO_PK primary key (QTYDISCOUNT_NO),
	CONSTRAINT QTYDISCOUNT_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES product(PRODUCT_NO));



create table PRODVENDOR (
    	PO_NO int not null,
	VENDOR_NO int null,
	PRODUCT_NO int not null,
	ORDER_DATE varchar(15) null,
	EXPECTED_RECVD_DATE date null,
	ACTUAL_RECVD_DATE varchar(15) null,
	purchased_QTY int null,
	shipping_charge CHAR(10) null,
	CONSTRAINT PRODVENDOR_PO_NO_PK PRIMARY KEY (PO_NO),
	CONSTRAINT PRODVENDOR_vendor_no_FK FOREIGN KEY (VENDOR_NO) REFERENCES vendor(VENDOR_NO),
	CONSTRAINT PRODVENDOR_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES product(PRODUCT_NO)); 


create table prod_warehouse(
	warehouse_no int,
	product_no int,
	WQOH int,
	constraint prod_warehouse_warehouse_no_PK primary key (warehouse_no),
	CONSTRAINT prod_warehouse_PRODUCT_NO_FK FOREIGN KEY (product_no) REFERENCES PRODUCT(product_no),
	CONSTRAINT prod_warehouse_warehouse_no_FK FOREIGN KEY (warehouse_no) REFERENCES warehouse(warehouse_no));


create table PRODUCTSET (
	PRODUCT_NO int not null,
	PRODUCTSET_NO int not null,
	PROD_QTY int null, 
	constraint PRODUCTSET_PK primary key (PRODUCTSET_NO),
	CONSTRAINT PRODUCTSET_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO)); 

CREATE TABLE backorder(
	backorder_no int,
	product_no int,
	bo_qty int,
	bo_date varchar(15),
	CONSTRAINT backorder_backorderno_pk PRIMARY KEY (backorder_no),
	CONSTRAINT backorder_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO));

CREATE TABLE CUSTOMER(
CUSTOMER_NO int not null,
LNAME VARCHAR(12),
FNAME VARCHAR(12),
STREET VARCHAR(30),
CITY VARCHAR(15),
STATE VARCHAR(2),
ZIP int,
REGION_NO int,
TEL_NO VARCHAR(15) ,
BALANCE int ,
CREDIT_LIMIT int,
BRANCH_NO int null,	
CONSTRAINT CUST_NUM_PK PRIMARY KEY (CUSTOMER_NO),
CONSTRAINT CUSTOMER_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES BRANCH (BRANCH_NO),
CONSTRAINT CUSTOMER_region_NO_FK FOREIGN KEY (REGION_NO) REFERENCES regions (REGION_NO));



create table region_state(
	state varchar(30),
	abbreviation varchar(2),
	city varchar(40),
	zip int,
	region_no int,
	constraint region_state_state_PK primary key (state),
	CONSTRAINT region_state_region_no_FK FOREIGN KEY (region_no) REFERENCES regions(region_no));

create table TAX (
	TAX_NO int not null,
	STATE VARCHAR(30) null,
	TAX_RATE VARCHAR(11) null, 
	constraint TAX_TAX_NO_PK primary key (TAX_NO),
	CONSTRAINT TAX_state_FK FOREIGN KEY (state) REFERENCES region_state(state)); 



CREATE TABLE EMPLOYEE(
EMPLOYEE_NO int not null,
LNAME VARCHAR(12) NOT NULL ,
FNAME VARCHAR(12) ,
STREET VARCHAR(30),
CITY VARCHAR(15),
STATE VARCHAR(2),
ZIP int,
STATUS int,
DOB varchar(15) NOT NULL ,
BRANCH_NO int NOT NULL ,
CONSTRAINT E_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES BRANCH (BRANCH_NO),
CONSTRAINT E_EMPLOYEE_NO_PK PRIMARY KEY (EMPLOYEE_NO));


create table Dept_Tables (
         Table_ID int, 
         Role_ID int ,
	 start_date  date,
	 end_date date,
	 state varchar(2),
	 dept_no int,
         CONSTRAINT Dept_Tables_Table_ID_pk primary key (Table_ID),
	 CONSTRAINT Dept_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));


create table salary(
         position int, 
         BS_NO int,
	 Max_Salary int,
	 Min_Salary int,
	 CONSTRAINT salary_BS_NO_Pk primary key (BS_NO),
	 CONSTRAINT salary_BS_NO_FK FOREIGN KEY (BS_NO) REFERENCES Branch_size(BS_NO),
	 CONSTRAINT salary_position_FK FOREIGN KEY (position) REFERENCES position(position_NO));

create table Dept_Branch(
	Branch_NO int,
	Dept_NO int,
	constraint Dept_Branch_Branch_NO_PK primary key (Branch_NO),
	CONSTRAINT Dept_Branch_region_no_FK FOREIGN KEY (Branch_NO) REFERENCES BRANCH(Branch_NO),
	CONSTRAINT Dept_Branch_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));




/*--------------THIRD------------------*/

create table Ship2Warehouse(
	warehouse_no int,
	PO_NO int,
	Ship_Comp_NO int,
	Condition varchar(15),
	EXPECTED_RECVD_DATE date,
	ACTUAL_RECVD_DATE date,
	WH_QTY INT,
	Ship_Method_NO int,
	constraint Ship2Warehouse_warehouse_no_PK primary key (warehouse_no),
	CONSTRAINT Ship2Warehouse_PO_NO_FK FOREIGN KEY (PO_NO) REFERENCES PRODVENDOR(PO_NO),
	CONSTRAINT Ship2Warehouse_Ship_Comp_NO_FK FOREIGN KEY (Ship_Comp_NO) REFERENCES COMPANY(Comp_NO));


create table EMP_payroll (
	payroll_NO int not null,
	amount int,
   	Emp_NO int, 
	constraint EMP_payroll_payroll_NO_PK primary key (payroll_NO),
	CONSTRAINT EMP_payroll_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	CONSTRAINT EMP_payroll_payroll_NO_FK FOREIGN KEY (payroll_NO) REFERENCES Payroll(payroll_NO)) ;


create table Employee_Position(
         Emp_POS_NO int, 
         Postion_no int,
	 start_date date,
	 end_date date,
	 employee_no int,
	 CONSTRAINT Employee_Position_Emp_POS_NO_pk primary key (Emp_POS_NO),
	 CONSTRAINT Employee_Position_Employee_No_FK FOREIGN KEY (employee_no) REFERENCES employee(employee_no),
	 CONSTRAINT Employee_Position_Position_No_FK FOREIGN KEY (Postion_no) REFERENCES position(position_NO));

create table Dependents(
         Emp_NO int, 
	 First_Name varchar(20),
	 Gender char(1),
	 DOB date,
	 SSN int,
	 Dependent_NO int,
	 Relation_Type int,
	 CONSTRAINT Dependents_Dependent_NO_pk primary key (Dependent_NO),
	 CONSTRAINT Dependent_NO_Employee_No_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT Dependent_NO_Relation_Type_FK FOREIGN KEY (Relation_Type) REFERENCES Relationship(Rel_Type));


create table Emp_Status (
         Emp_NO int not null , 
         Status_NO int,
	 start_date date,
	 end_date date,
         CONSTRAINT Emp_Status_pk primary key (start_date),
	 CONSTRAINT Emp_Status_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES EMPLOYEE (employee_no),
	 CONSTRAINT Emp_Status_Status_NO_FK FOREIGN KEY (Status_NO) REFERENCES Employement_Status (Status_NO));

create table ORDERS (
	ORDER_NO int not null,
	EMPLOYEE_NO int null,
	BRANCH_NO int null,
	SHIP_Method_NO int null,	
	TAX_STATUS CHAR(1) null,
	SUBTOTAL int null,
	TAX_AMT int null,
	SHIPPING_CHARGE int null,
	TOTAL_AMT int null,
	CUSTOMER_NO int null,
	ORDER_DATE varchar(15) not null,
	SHIP_DATE varchar(15) null,
	Ship_Comp_NO int,
	constraint ORDERS_ORDERNO_PK primary key (ORDER_NO),
	CONSTRAINT ORDERS_employee_NO_FK FOREIGN KEY (EMPLOYEE_NO) REFERENCES employee (EMPLOYEE_NO),
	CONSTRAINT ORDERS_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES branch (BRANCH_NO),
	CONSTRAINT ORDERS_SHIP_Method_NO_FK FOREIGN KEY (SHIP_Method_NO) REFERENCES Ship_Method (SHIP_Method_NO),
	CONSTRAINT ORDERS_CUSTOMER_NO_FK FOREIGN KEY (CUSTOMER_NO) REFERENCES customer (CUSTOMER_NO),
	CONSTRAINT ORDERS_Ship_Comp_NO_FK FOREIGN KEY (Ship_Comp_NO) REFERENCES Company (Comp_NO)); 

create table INQUIRY(
	Inquiry_ID int,
	Inquiry date,
	Start_time int,
	End_time int,
	Cat_ID varchar(20),
	customer_NO int,
	total_time int,
	constraint INQUIRY_Inquiry_ID_PK primary key (Inquiry_ID),
	CONSTRAINT INQUIRY_customer_NO_FK FOREIGN KEY (customer_NO) REFERENCES CUSTOMER(customer_NO),
	CONSTRAINT INQUIRY_Cat_ID_FK FOREIGN KEY (Cat_ID) REFERENCES Inquiry_Category(Cat_ID)); 

create table state_capital(
	city varchar(40),
	state varchar(30),
	zip int,
	region_no int,
	constraint state_capital_city_PK primary key (city),
	CONSTRAINT state_capital_region_no_FK FOREIGN KEY (region_no) REFERENCES regions(region_no),
	CONSTRAINT state_capital_state_FK FOREIGN KEY (state) REFERENCES region_state(state));


create table Dept_Mgr(
	 Emp_NO int, 
         Dept_NO int, 
         start_date date,
	 end_date date,
         CONSTRAINT DM_start_date_pk primary key (start_date),
	 CONSTRAINT DM_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT DM_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table Dept_Emp(
	 Emp_NO int, 
         Dept_NO int, 
         start_date date,
	 end_date date,
         CONSTRAINT DE_start_date_pk primary key (start_date),
	 CONSTRAINT DE_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT DE_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table Internal_EMP_Training(
         Emp_NO int, 
         Dept_NO int,
	 start_date date,
	 end_date date,
	 Train_NO int,
	 CONSTRAINT IET_start_date_pk primary key (start_date),
	 CONSTRAINT IET_Train_NO_FK FOREIGN KEY (Train_NO) REFERENCES Training(Train_NO),
	 CONSTRAINT IET_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
	 CONSTRAINT IET_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table External_EMP_Training(
	 Emp_NO int,
	 Comp_NO int,
	 start_date date,
	 end_date date,
	 Train_NO int,
	 CONSTRAINT EET_start_date_pk primary key (start_date),
	 CONSTRAINT EET_Train_NO_FK FOREIGN KEY (Train_NO) REFERENCES Training(Train_NO),
	 CONSTRAINT EET_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
	 CONSTRAINT EET_Comp_NO_FK FOREIGN KEY (Comp_NO) REFERENCES Company(Comp_NO));

create table External_EMP_Certification(
		 Emp_NO int,
		 Comp_NO int,
		 start_date date,
		 end_date date,
		 cert_NO int,
		 CONSTRAINT EEC_start_date_pk primary key (start_date),
		 CONSTRAINT EEC_Cert_NO_FK FOREIGN KEY (Cert_NO) REFERENCES Certificate(Cert_NO),
		 CONSTRAINT EEC_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
		 CONSTRAINT EEC_Comp_NO_FK FOREIGN KEY (Comp_NO) REFERENCES Company(Comp_NO));



create table EMP_Skill(
		 Emp_NO int,
		 Skill_NO int,
		 level varchar(10),
		 CONSTRAINT ES_Skill_NO_pk primary key (Emp_NO),
		 CONSTRAINT ES_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(Employee_NO),
		 CONSTRAINT ES_Skill_NO_FK FOREIGN KEY (Skill_NO) REFERENCES Skill(Skill_NO));


create table User_Info(
		 Emp_NO int,
		 UserID int,
		 start_date date,
		 end_date date,
		 CONSTRAINT User_Info_UserID_pk primary key (UserID),
		 CONSTRAINT User_Info_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(Employee_NO));


create table EMP_Education(
         Emp_No int, 
         Inst_NO int,
		 start_date date,
		 end_date date,
		 Minor_NO int,
		 Major_NO int,
		 Edu_Type_NO int,
		 Edu_ID int,
		 Edu_Completed char(1),
		 CONSTRAINT EE_start_date_pk primary key (Edu_ID),
		 CONSTRAINT EE_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
		 CONSTRAINT EE_Inst_NO_FK FOREIGN KEY (Inst_NO) REFERENCES Institution(Inst_NO),
		 CONSTRAINT EE_Major_NO_FK FOREIGN KEY (Major_NO) REFERENCES Major(Major_NO),
		 CONSTRAINT EE_Minor_NO_FK FOREIGN KEY (Minor_NO) REFERENCES Minor(Minor_NO),
		 CONSTRAINT EE_Edu_Type_NO_FK FOREIGN KEY (Edu_Type_NO) REFERENCES Education_Type(Edu_Type_NO));


/*--------------FOURTH------------------*/

create table RETURNPROD_Condition(
        Cond_NO int, 
        RETR_QTY int,
	warehouse_no int,
	constraint RETURNPROD_Condition_Cond_NO_PK primary key (Cond_NO),
	CONSTRAINT RETURNPROD_Condition_Cond_NO_FK FOREIGN KEY (Cond_NO) REFERENCES Prod_Condition(Cond_NO),
	CONSTRAINT RETURNPROD_Condition_warehouse_no_FK FOREIGN KEY (warehouse_no) REFERENCES warehouse(warehouse_no));


create table Emp_salary(
         Emp_POS_NO int, 
         Amount int,
	 start_date date,
	 end_date date,
	 CONSTRAINT ES_start_date_pk primary key (start_date),
	 CONSTRAINT ES_Emp_POS_NO_FK FOREIGN KEY (Emp_POS_NO) REFERENCES Employee_Position(Emp_POS_NO));

create table Sales_commission(
	         Emp_NO int, 
         	 order_NO int,
		 Amount int,
		 Comm_date date,
		 CONSTRAINT Sales_commission_start_date_pk primary key (Comm_date),
		 CONSTRAINT Sales_commission_Emp_POS_NO_FK FOREIGN KEY (Emp_NO) REFERENCES Employee(Employee_NO),
		 CONSTRAINT Sales_commission_order_no_FK FOREIGN KEY (order_NO) REFERENCES orders(order_NO));

select * from orderline;
create table ORDERLINE (
	ORDERLINE_NO int not null,
	PRODUCT_NO int null,
	QTY int null,
	ORDER_NO int null, 
	constraint ORDERLINE_ORDERLINENO_PK primary key (ORDERLINE_NO),
	CONSTRAINT ORDERLINE_order_no_FK FOREIGN KEY (order_NO) REFERENCES orders(order_NO),
	CONSTRAINT ORDERLINE_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT(PRODUCT_NO)); 




create table User_Role(
		 Dept_NO int,
		 UserID int,
		 start_date date,
		 end_date date,
		 CONSTRAINT User_Role_UserID_pk primary key (start_date),
		 CONSTRAINT User_Role_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO),
		 CONSTRAINT User_Role_UserID_FK FOREIGN KEY (UserID) REFERENCES User_Info(UserID));



/*--------------FIFTH------------------*/

create table RETURNPROD (
        ORDERLINE_NO int, 
        RETR_QTY int,
	RETURN_ID int not null,	
	DATE_RETURNED varchar(15) not null,
        AMOUNT_REFUNDED int ,
        RETURN_CODE int,
	constraint RETURNPROD_RETURNID_PK primary key (RETURN_ID),
	CONSTRAINT RETURNPROD_ORDERLINE_NO_FK FOREIGN KEY (ORDERLINE_NO) REFERENCES ORDERLINE(ORDERLINE_NO),
	CONSTRAINT RETURNPROD_RETURN_CODE_FK FOREIGN KEY (RETURN_CODE) REFERENCES return_category(RETURN_CODE));




create table Order_Inquiry(
	Order_Inquiry_ID int,
	Date_Resolved date,
	Comments varchar(60),
	Order_NO int,
	Inquiry_ID int,
	Employee_NO int,
	Customer_NO int,
	constraint Order_Inquiry_Order_Inquiry_ID_PK primary key (Order_Inquiry_ID),
	CONSTRAINT Order_Inquiry_customer_NO_FK FOREIGN KEY (customer_NO) REFERENCES CUSTOMER(customer_NO),
	CONSTRAINT Order_Inquiry_Order_NO_FK FOREIGN KEY (Order_NO) REFERENCES ORDERS(Order_NO),
	CONSTRAINT Order_Inquiry_Employee_NO_FK FOREIGN KEY (Employee_NO) REFERENCES Employee(Employee_NO),
	CONSTRAINT Order_Inquiry_Inquiry_ID_FK FOREIGN KEY (Inquiry_ID) REFERENCES INQUIRY(Inquiry_ID)); 


/*--------------SIXTH------------------*/

create table Return_Sales_Commission(
	Emp_NO int,
	Return_ID int,
	Amount int,
	constraint Return_Sales_Commission_Return_ID_PK primary key (Return_ID),
	CONSTRAINT Return_Sales_Commission_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES Employee(Employee_NO),
	CONSTRAINT Return_Sales_Commission_Return_ID_FK FOREIGN KEY (Return_ID) REFERENCES RETURNPROD(Return_ID)); 

	

create table Inquiry_Action(
	IA_ID int,
	Inquiry_ID int,
	Description varchar(60),
	Order_Inquiry_ID int,
	constraint Inquiry_Action_IA_ID_PK primary key (IA_ID),
	CONSTRAINT Inquiry_Action_Order_Inquiry_ID_FK FOREIGN KEY (Order_Inquiry_ID) REFERENCES Order_Inquiry(Order_Inquiry_ID),
	CONSTRAINT Inquiry_Action_Inquiry_ID_FK FOREIGN KEY (Inquiry_ID) REFERENCES INQUIRY(Inquiry_ID)); 


/*--------------SEVENTH------------------*/

create table OrderInquiry_Action(
	OIA_ID int,
	Date_Action date,
	Adj_Ship_Amt int,
	Adj_Price_Amt int,
	Adj_QTY int,
	Adj_Rent_Amt int,
	Adj_Tax int,
	IA_ID int,
	Orderline_NO int,
	constraint OrderInquiry_Action_OIA_ID_PK primary key (OIA_ID),
	CONSTRAINT OrderInquiry_Action_IA_ID_FK FOREIGN KEY (IA_ID) REFERENCES Inquiry_Action(IA_ID),
	CONSTRAINT OrderInquiry_Action_Orderline_NO_FK FOREIGN KEY (Orderline_NO) REFERENCES ORDERLINE(Orderline_NO)); 

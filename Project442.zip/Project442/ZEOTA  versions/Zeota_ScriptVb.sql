Create database ZeotaV1_c
use ZeotaV1_c

/*--------------FIRST------------------*/
Create table VENDOR (
	VENDOR_NO int not null,
	NAME VARCHAR(50) null,
        STREET VARCHAR(30),
        CITY VARCHAR(12),
        STATE CHAR(2),
        ZIP int,
	TEL_NO VARCHAR(12) null, 
	constraint VENDOR_PK primary key (VENDOR_NO) ) ;


create table PRODUCT (
	PRODUCT_NO int not null,
	BRAND VARCHAR(15) null,
	CLASS VARCHAR(20) null,
	PRODUCT_DESCRIPTION VARCHAR(50) null,
	UNIT_PRICE int null,
	UNIT_COST int null,
	PRODUCT_CATEGORY VARCHAR(15) null,
	QOH int null,
	ORDER_LEVEL int null,
	ORDER_QTY int null,
	BACK_ORDER int null,
	AVAIL_DATE varchar(15) null,
	DAMAGED_QTY int null, 
	constraint PRODUCT_PRODUCTNO_PK primary key (PRODUCT_NO) ); 


create table PROMOTION (
	PROMOTION_NO int,
	promotion_name int,
	constraint P_PROMOTION_NO_PK primary key (PROMOTION_NO) ); 
alter table promotion
alter column promotion_name  varchar(50)




create table Warehouse(
	warehouse_no int,
	name varchar(50),
	street varchar(30),
	city varchar(12),
	state varchar(2),
	zip int,
	TEL_NO varchar(12),
	constraint w_warehouse_no_PK primary key (warehouse_no));

CREATE TABLE ship_method(
Ship_Method_NO int,
Mthod_name varchar(30),
constraint ship_method_Ship_Method_NO_PK primary key (Ship_Method_NO));



create table return_category(
	return_code int,
	description varchar(40),
	constraint return_category_return_code_PK primary key (return_code));

create table INQUIRY_Category (
	Cat_ID varchar(20),
	category varchar(50),
	constraint INQUIRY_Category_ID_PK primary key (Cat_ID)); 


create table regions(
	region_no int,
	timezone varchar(40),
	constraint regions_region_no_PK primary key (region_no));

create table BRANCH (
	BRANCH_NO int not null,
	STREET VARCHAR(30) null,
	CITY VARCHAR(15) not null,
	STATE VARCHAR(2) ,
        REGION_NO int,
	ZIP int null constraint BRANCH_ZIP_CHK check ( ZIP > 0 ) , 
	constraint BRANCH_BRANCHNO_PK primary key (BRANCH_NO) );

create table List_Tables(
	Table_ID int,
	Table_Name varchar(30),
	constraint List_Tables_Table_ID primary key (Table_ID));


create table Training(
		 Train_NO int,
		 Training_name varchar(30),
		 CONSTRAINT Training_Emp_NO_FK PRIMARY KEY (Train_NO));


create table Company(
	Comp_NO int,
	Comp_name varchar(30),
	Phone# varchar(30),
	StAddress varchar(30),
	city varchar(30),
	ZIP int,
	State varchar(2),
	CONSTRAINT C_Comp_NO_pk primary key (Comp_NO));




create table Certificate(
		Cert_NO int,
		Cert_name varchar(30),
		CONSTRAINT C_start_date_pk primary key (Cert_NO));


create table Roles(
		Role_ID int,
		Role_name varchar(30),
		CONSTRAINT Roles_Role_ID_pk primary key (Role_ID));

create table Institution(
         Inst_NO int, 
         Institute_name varchar(30),
	 city varchar(30),
	 state varchar(2),
	 CONSTRAINT I_Inst_NO_pk primary key (Inst_NO));


create table Skill(
		 Skill_NO int,
		 Skill_name varchar(30),
		 CONSTRAINT S_Skill_NO_pk primary key (Skill_NO));



create table Minor(
		 Minor_NO int,
		 Minor_name varchar(30),
		 CONSTRAINT Minor_Minor_NO_pk primary key (Minor_NO));

create table Major(
         Major_NO int, 
         Major_name varchar(30),
		 CONSTRAINT M_Major_NO_pk primary key (Major_NO));

create table Education_Type(
         Edu_Type_No int, 
         Type_name varchar(30),
	 CONSTRAINT E_Edu_Type_No_pk primary key (Edu_Type_No));



create table employement_status (
         status_no int not null , 
         description varchar(40) ,
         CONSTRAINT employee_status_pk1 primary key (status_no));



create table position (
        position_NO int not null , 
        description varchar(40) ,
    CONSTRAINT employee_position_pk  primary key (position_NO));

create table payroll (
	payroll_NO int,
	start_date date,
   	end_date date, 
	CONSTRAINT EP_payroll_NO_PK primary KEY (payroll_NO)) ;


create table Prod_Condition(
	Cond_NO int,
	Cond_Name varchar(30),
	CONSTRAINT Prod_Condition_Cond_NO_PK primary KEY (Cond_NO)) ;



create table Branch_Size(
	BS_NO int,
	Name varchar(40),
	CONSTRAINT Branch_Size_BS_NO_PK primary KEY (BS_NO)) ;



create table Relationship(
	Rel_Type int,
	Rel_Name varchar(40),
	CONSTRAINT Relationship_Rel_Type_PK primary KEY (Rel_Type)) ;

create table Department (
         Dept_NO int, 
         Dept_name varchar(30) ,
		 street  varchar(40),
		 city varchar(15),
		 state varchar(2),
		 zip int,
         CONSTRAINT D_Dept_NO_pk primary key (Dept_NO));



/*--------------SECOND------------------*/


create table Return2Vendor(
	Return_Date int not null,
	VENDOR_NO int,
        PRODUCT_NO int,
        QTY int,
        V_Confirmation_No VARCHAR(4),
        Amount int,
	constraint Return_Date_PK primary key (Return_Date),
	CONSTRAINT PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO),
	CONSTRAINT VENDOR_NO_FK FOREIGN KEY (VENDOR_NO) REFERENCES VENDOR (VENDOR_NO)) ;

alter table Return2Vendor 
drop constraint Return_Date_PK;

ALTER TABLE Return2Vendor
alter column return_date nvarchar(20) not null;

ALTER TABLE Return2Vendor
ADD CONSTRAINT Return_Date_PK PRIMARY KEY (Return_date);




create table Vndor_PROMOTION (
	VPID int,
	V_Price int,
	START_DATE date,
	END_DATE date,
	Vendor_no int,
	promo_no int,
	constraint Vndor_PROMOTION_VPID_PK primary key (VPID),
	CONSTRAINT Vndor_PROMOTION_PROMO_NO_FK FOREIGN KEY (promo_no) REFERENCES Promotion (PROMOTION_NO),
	CONSTRAINT Vndor_PROMOTION_Vendor_no_FK FOREIGN KEY (vendor_no) REFERENCES Vendor (vendor_no)); 



create table Prod_Promotion (
	ppid int,
	p_price int,
	start_date date,
	end_date date,
	product_no int,
	PROMO_ID int,
	constraint Prod_Promotion_PPID_PK primary key (PPID),
	CONSTRAINT Prod_Promotion_product_NO_FK FOREIGN KEY (product_NO) REFERENCES product (product_NO),
	CONSTRAINT Prod_Promotion_PROMO_ID_FK FOREIGN KEY (PROMO_ID) REFERENCES Promotion (PROMOTION_NO)); 




create table VENDORPRICE (
	VPRICE_NO int not null,
	VENDOR_NO int not null,
	PRODUCT_NO int not null,
	VPRICE int not null,
	DISCOUNT VARCHAR(4) null,
	constraint VENDORPRICE_PK primary key (VPRICE_NO),
	CONSTRAINT VENDORPRICE_product_NO_FK FOREIGN KEY (product_NO) REFERENCES product (product_NO),
	CONSTRAINT VENDORPRICE_Vendor_no_FK FOREIGN KEY (vendor_no) REFERENCES Vendor (vendor_no)); 


create table Vendor_QTYDISCOUNT (
	QTYDISCOUNT_NO int not null,
	D_PRICE int null,
	MIN_QTY int null,
	MAX_QTY CHAR(10) null,
	VENDOR_NO int null,
	constraint QTYDISCOUNT_PK primary key (QTYDISCOUNT_NO),
	CONSTRAINT VQ_VENDOR_NO_FK FOREIGN KEY (VENDOR_NO) REFERENCES VENDOR (VENDOR_NO)); 

create table QTYDISCOUNT (
	QTYDISCOUNT_NO int not null,
	D_PRICE int null,
	MIN_QTY int null,
	MAX_QTY CHAR(10) null,
	PRODUCT_NO int null,
	constraint QTYDISCOUNT_QTYDISCOUNT_NO_PK primary key (QTYDISCOUNT_NO),
	CONSTRAINT QTYDISCOUNT_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES product(PRODUCT_NO));


create table PRODVENDOR (
    	PO_NO int not null,
	VENDOR_NO int null,
	PRODUCT_NO int not null,
	ORDER_DATE varchar(15) null,
	EXPECTED_RECVD_DATE date null,
	ACTUAL_RECVD_DATE varchar(15) null,
	purchased_QTY int null,
	shipping_charge CHAR(10) null,
	CONSTRAINT PRODVENDOR_PO_NO_PK PRIMARY KEY (PO_NO),
	CONSTRAINT PRODVENDOR_vendor_no_FK FOREIGN KEY (VENDOR_NO) REFERENCES vendor(VENDOR_NO),
	CONSTRAINT PRODVENDOR_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES product(PRODUCT_NO)); 


create table prod_warehouse(
	warehouse_no int,
	product_no int,
	WQOH int,
	constraint prod_warehouse_warehouse_no_PK primary key (warehouse_no),
	CONSTRAINT prod_warehouse_PRODUCT_NO_FK FOREIGN KEY (product_no) REFERENCES PRODUCT(product_no),
	CONSTRAINT prod_warehouse_warehouse_no_FK FOREIGN KEY (warehouse_no) REFERENCES warehouse(warehouse_no));


create table PRODUCTSET (
	PRODUCT_NO int not null,
	PRODUCTSET_NO int not null,
	PROD_QTY int null, 
	constraint PRODUCTSET_PK primary key (PRODUCTSET_NO),
	CONSTRAINT PRODUCTSET_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO)); 

CREATE TABLE backorder(
	backorder_no int,
	product_no int,
	bo_qty int,
	bo_date varchar(15),
	CONSTRAINT backorder_backorderno_pk PRIMARY KEY (backorder_no),
	CONSTRAINT backorder_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT (PRODUCT_NO));

CREATE TABLE CUSTOMER(
CUSTOMER_NO int not null,
LNAME VARCHAR(12),
FNAME VARCHAR(12),
STREET VARCHAR(30),
CITY VARCHAR(15),
STATE VARCHAR(2),
ZIP int,
REGION_NO int,
TEL_NO VARCHAR(15) ,
BALANCE int ,
CREDIT_LIMIT int,
BRANCH_NO int null,	
CONSTRAINT CUST_NUM_PK PRIMARY KEY (CUSTOMER_NO),
CONSTRAINT CUSTOMER_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES BRANCH (BRANCH_NO),
CONSTRAINT CUSTOMER_region_NO_FK FOREIGN KEY (REGION_NO) REFERENCES regions (REGION_NO));

create table region_state(
	state varchar(30),
	abbreviation varchar(2),
	city varchar(40),
	zip int,
	region_no int,
	constraint region_state_state_PK primary key (state),
	CONSTRAINT region_state_region_no_FK FOREIGN KEY (region_no) REFERENCES regions(region_no));

create table TAX (
	TAX_NO int not null,
	STATE VARCHAR(30) null,
	TAX_RATE VARCHAR(11) null, 
	constraint TAX_TAX_NO_PK primary key (TAX_NO),
	CONSTRAINT TAX_state_FK FOREIGN KEY (state) REFERENCES region_state(state)); 



CREATE TABLE EMPLOYEE(
EMPLOYEE_NO int not null,
LNAME VARCHAR(12) NOT NULL ,
FNAME VARCHAR(12) ,
STREET VARCHAR(30),
CITY VARCHAR(15),
STATE VARCHAR(2),
ZIP int,
STATUS int,
DOB varchar(15) NOT NULL ,
BRANCH_NO int NOT NULL ,
CONSTRAINT E_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES BRANCH (BRANCH_NO),
CONSTRAINT E_EMPLOYEE_NO_PK PRIMARY KEY (EMPLOYEE_NO));


create table Dept_Tables (
         Table_ID int, 
         Role_ID int ,
	 start_date  date,
	 end_date date,
	 state varchar(2),
	 dept_no int,
         CONSTRAINT Dept_Tables_Table_ID_pk primary key (Table_ID),
	 CONSTRAINT Dept_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));



create table salary(
         position int, 
         BS_NO int,
	 Max_Salary int,
	 Min_Salary int,
	 CONSTRAINT salary_BS_NO_Pk primary key (BS_NO),
	 CONSTRAINT salary_BS_NO_FK FOREIGN KEY (BS_NO) REFERENCES Branch_size(BS_NO),
	 CONSTRAINT salary_position_FK FOREIGN KEY (position) REFERENCES position(position_NO));

create table Dept_Branch(
	Branch_NO int,
	Dept_NO int,
	constraint Dept_Branch_Branch_NO_PK primary key (Branch_NO),
	CONSTRAINT Dept_Branch_region_no_FK FOREIGN KEY (Branch_NO) REFERENCES BRANCH(Branch_NO),
	CONSTRAINT Dept_Branch_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));
;


/*--------------THIRD------------------*/

create table Ship2Warehouse(
	warehouse_no int,
	PO_NO int,
	Ship_Comp_NO int,
	Condition varchar(15),
	EXPECTED_RECVD_DATE date,
	ACTUAL_RECVD_DATE date,
	WH_QTY INT,
	Ship_Method_NO int,
	constraint Ship2Warehouse_warehouse_no_PK primary key (warehouse_no),
	CONSTRAINT Ship2Warehouse_PO_NO_FK FOREIGN KEY (PO_NO) REFERENCES PRODVENDOR(PO_NO),
	CONSTRAINT Ship2Warehouse_Ship_Comp_NO_FK FOREIGN KEY (Ship_Comp_NO) REFERENCES COMPANY(Comp_NO));


create table EMP_payroll (
	payroll_NO int not null,
	amount int,
   	Emp_NO int, 
	constraint EMP_payroll_payroll_NO_PK primary key (payroll_NO),
	CONSTRAINT EMP_payroll_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	CONSTRAINT EMP_payroll_payroll_NO_FK FOREIGN KEY (payroll_NO) REFERENCES Payroll(payroll_NO)) ;


create table Employee_Position(
         Emp_POS_NO int, 
         Postion_no int,
	 start_date date,
	 end_date date,
	 employee_no int,
	 CONSTRAINT Employee_Position_Emp_POS_NO_pk primary key (Emp_POS_NO),
	 CONSTRAINT Employee_Position_Employee_No_FK FOREIGN KEY (employee_no) REFERENCES employee(employee_no),
	 CONSTRAINT Employee_Position_Position_No_FK FOREIGN KEY (Postion_no) REFERENCES position(position_NO));



create table Dependents(
         Emp_NO int, 
	 First_Name varchar(20),
	 Gender char(1),
	 DOB date,
	 SSN int,
	 Dependent_NO int,
	 Relation_Type int,
	 CONSTRAINT Dependents_Dependent_NO_pk primary key (Dependent_NO),
	 CONSTRAINT Dependent_NO_Employee_No_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT Dependent_NO_Relation_Type_FK FOREIGN KEY (Relation_Type) REFERENCES Relationship(Rel_Type));


create table Emp_Status (
         Emp_NO int not null , 
         Status_NO int,
	 start_date date,
	 end_date date,
         CONSTRAINT Emp_Status_pk primary key (start_date),
	 CONSTRAINT Emp_Status_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES EMPLOYEE (employee_no),
	 CONSTRAINT Emp_Status_Status_NO_FK FOREIGN KEY (Status_NO) REFERENCES Employement_Status (Status_NO));

insert into employement_status values(	1,'Active');
insert into employement_status values(	2,'Retired');
insert into employement_status values(	3,'Terminated');


create table ORDERS (
	ORDER_NO int not null,
	EMPLOYEE_NO int null,
	BRANCH_NO int null,
	SHIP_Method_NO int null,	
	TAX_STATUS CHAR(1) null,
	SUBTOTAL int null,
	TAX_AMT int null,
	SHIPPING_CHARGE int null,
	TOTAL_AMT int null,
	CUSTOMER_NO int null,
	ORDER_DATE varchar(15) not null,
	SHIP_DATE varchar(15) null,
	Ship_Comp_NO int,
	constraint ORDERS_ORDERNO_PK primary key (ORDER_NO),
	CONSTRAINT ORDERS_employee_NO_FK FOREIGN KEY (EMPLOYEE_NO) REFERENCES employee (EMPLOYEE_NO),
	CONSTRAINT ORDERS_BRANCH_NO_FK FOREIGN KEY (BRANCH_NO) REFERENCES branch (BRANCH_NO),
	CONSTRAINT ORDERS_SHIP_Method_NO_FK FOREIGN KEY (SHIP_Method_NO) REFERENCES Ship_Method (SHIP_Method_NO),
	CONSTRAINT ORDERS_CUSTOMER_NO_FK FOREIGN KEY (CUSTOMER_NO) REFERENCES customer (CUSTOMER_NO),
	CONSTRAINT ORDERS_Ship_Comp_NO_FK FOREIGN KEY (Ship_Comp_NO) REFERENCES Company (Comp_NO)); 

create table INQUIRY(
	Inquiry_ID int,
	Inquiry date,
	Start_time int,
	End_time int,
	Cat_ID varchar(20),
	customer_NO int,
	total_time int,
	constraint INQUIRY_Inquiry_ID_PK primary key (Inquiry_ID),
	CONSTRAINT INQUIRY_customer_NO_FK FOREIGN KEY (customer_NO) REFERENCES CUSTOMER(customer_NO),
	CONSTRAINT INQUIRY_Cat_ID_FK FOREIGN KEY (Cat_ID) REFERENCES Inquiry_Category(Cat_ID)); 

create table state_capital(
	city varchar(40),
	state varchar(30),
	zip int,
	region_no int,
	constraint state_capital_city_PK primary key (city),
	CONSTRAINT state_capital_region_no_FK FOREIGN KEY (region_no) REFERENCES regions(region_no),
	CONSTRAINT state_capital_state_FK FOREIGN KEY (state) REFERENCES region_state(state));


create table Dept_Mgr(
	 Emp_NO int, 
         Dept_NO int, 
         start_date date,
	 end_date date,
         CONSTRAINT DM_start_date_pk primary key (start_date),
	 CONSTRAINT DM_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT DM_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table Dept_Emp(
	 Emp_NO int, 
         Dept_NO int, 
         start_date date,
	 end_date date,
         CONSTRAINT DE_start_date_pk primary key (start_date),
	 CONSTRAINT DE_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_no),
	 CONSTRAINT DE_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table Internal_EMP_Training(
         Emp_NO int, 
         Dept_NO int,
	 start_date date,
	 end_date date,
	 Train_NO int,
	 CONSTRAINT IET_start_date_pk primary key (start_date),
	 CONSTRAINT IET_Train_NO_FK FOREIGN KEY (Train_NO) REFERENCES Training(Train_NO),
	 CONSTRAINT IET_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
	 CONSTRAINT IET_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO));

create table External_EMP_Training(
	 Emp_NO int,
	 Comp_NO int,
	 start_date date,
	 end_date date,
	 Train_NO int,
	 CONSTRAINT EET_start_date_pk primary key (start_date),
	 CONSTRAINT EET_Train_NO_FK FOREIGN KEY (Train_NO) REFERENCES Training(Train_NO),
	 CONSTRAINT EET_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
	 CONSTRAINT EET_Comp_NO_FK FOREIGN KEY (Comp_NO) REFERENCES Company(Comp_NO));

create table External_EMP_Certification(
		 Emp_NO int,
		 Comp_NO int,
		 start_date date,
		 end_date date,
		 cert_NO int,
		 CONSTRAINT EEC_start_date_pk primary key (start_date),
		 CONSTRAINT EEC_Cert_NO_FK FOREIGN KEY (Cert_NO) REFERENCES Certificate(Cert_NO),
		 CONSTRAINT EEC_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
		 CONSTRAINT EEC_Comp_NO_FK FOREIGN KEY (Comp_NO) REFERENCES Company(Comp_NO));



create table EMP_Skill(
		 Emp_NO int,
		 Skill_NO int,
		 level varchar(10),
		 CONSTRAINT ES_Skill_NO_pk primary key (Emp_NO),
		 CONSTRAINT ES_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(Employee_NO),
		 CONSTRAINT ES_Skill_NO_FK FOREIGN KEY (Skill_NO) REFERENCES Skill(Skill_NO));


create table User_Info(
		 Emp_NO int,
		 UserID int,
		 start_date date,
		 end_date date,
		 CONSTRAINT User_Info_UserID_pk primary key (UserID),
		 CONSTRAINT User_Info_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(Employee_NO));


create table EMP_Education(
         Emp_No int, 
         Inst_NO int,
		 start_date date,
		 end_date date,
		 Minor_NO int,
		 Major_NO int,
		 Edu_Type_NO int,
		 Edu_ID int,
		 Edu_Completed char(1),
		 CONSTRAINT EE_start_date_pk primary key (Edu_ID),
		 CONSTRAINT EE_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES employee(employee_NO),
		 CONSTRAINT EE_Inst_NO_FK FOREIGN KEY (Inst_NO) REFERENCES Institution(Inst_NO),
		 CONSTRAINT EE_Major_NO_FK FOREIGN KEY (Major_NO) REFERENCES Major(Major_NO),
		 CONSTRAINT EE_Minor_NO_FK FOREIGN KEY (Minor_NO) REFERENCES Minor(Minor_NO),
		 CONSTRAINT EE_Edu_Type_NO_FK FOREIGN KEY (Edu_Type_NO) REFERENCES Education_Type(Edu_Type_NO));


/*--------------FOURTH------------------*/


create table Emp_salary(
         Emp_POS_NO int, 
         Amount int,
	 start_date date,
	 end_date date,
	 CONSTRAINT ES_start_date_pk primary key (start_date),
	 CONSTRAINT ES_Emp_POS_NO_FK FOREIGN KEY (Emp_POS_NO) REFERENCES Employee_Position(Emp_POS_NO));

create table Sales_commission(
	         Emp_NO int, 
         	 order_NO int,
		 Amount int,
		 Comm_date date,
		 CONSTRAINT Sales_commission_start_date_pk primary key (Comm_date),
		 CONSTRAINT Sales_commission_Emp_POS_NO_FK FOREIGN KEY (Emp_NO) REFERENCES Employee(Employee_NO),
		 CONSTRAINT Sales_commission_order_no_FK FOREIGN KEY (order_NO) REFERENCES orders(order_NO));


create table ORDERLINE (
	ORDERLINE_NO int not null,
	PRODUCT_NO int null,
	QTY int null,
	ORDER_NO int null, 
	constraint ORDERLINE_ORDERLINENO_PK primary key (ORDERLINE_NO),
	CONSTRAINT ORDERLINE_order_no_FK FOREIGN KEY (order_NO) REFERENCES orders(order_NO),
	CONSTRAINT ORDERLINE_PRODUCT_NO_FK FOREIGN KEY (PRODUCT_NO) REFERENCES PRODUCT(PRODUCT_NO)); 




create table User_Role(
		 Dept_NO int,
		 UserID int,
		 start_date date,
		 end_date date,
		 CONSTRAINT User_Role_UserID_pk primary key (start_date),
		 CONSTRAINT User_Role_Dept_NO_FK FOREIGN KEY (Dept_NO) REFERENCES Department(Dept_NO),
		 CONSTRAINT User_Role_UserID_FK FOREIGN KEY (UserID) REFERENCES User_Info(UserID));



/*--------------FIFTH------------------*/

create table RETURNPROD (
        ORDERLINE_NO int, 
        RETR_QTY int,
	RETURN_ID int not null,	
	DATE_RETURNED varchar(15) not null,
        AMOUNT_REFUNDED int ,
        RETURN_CODE int,
	constraint RETURNPROD_RETURNID_PK primary key (RETURN_ID),
	CONSTRAINT RETURNPROD_ORDERLINE_NO_FK FOREIGN KEY (ORDERLINE_NO) REFERENCES ORDERLINE(ORDERLINE_NO),
	CONSTRAINT RETURNPROD_RETURN_CODE_FK FOREIGN KEY (RETURN_CODE) REFERENCES return_category(RETURN_CODE));




create table Order_Inquiry(
	Order_Inquiry_ID int,
	Date_Resolved date,
	Comments varchar(60),
	Order_NO int,
	Inquiry_ID int,
	Employee_NO int,
	Customer_NO int,
	constraint Order_Inquiry_Order_Inquiry_ID_PK primary key (Order_Inquiry_ID),
	CONSTRAINT Order_Inquiry_customer_NO_FK FOREIGN KEY (customer_NO) REFERENCES CUSTOMER(customer_NO),
	CONSTRAINT Order_Inquiry_Order_NO_FK FOREIGN KEY (Order_NO) REFERENCES ORDERS(Order_NO),
	CONSTRAINT Order_Inquiry_Employee_NO_FK FOREIGN KEY (Employee_NO) REFERENCES Employee(Employee_NO),
	CONSTRAINT Order_Inquiry_Inquiry_ID_FK FOREIGN KEY (Inquiry_ID) REFERENCES INQUIRY(Inquiry_ID)); 


/*--------------SIXTH------------------*/

create table Return_Sales_Commission(
	Emp_NO int,
	Return_ID int,
	Amount int,
	constraint Return_Sales_Commission_Return_ID_PK primary key (Return_ID),
	CONSTRAINT Return_Sales_Commission_Emp_NO_FK FOREIGN KEY (Emp_NO) REFERENCES Employee(Employee_NO),
	CONSTRAINT Return_Sales_Commission_Return_ID_FK FOREIGN KEY (Return_ID) REFERENCES RETURNPROD(Return_ID)); 



create table Inquiry_Action(
	IA_ID int,
	Inquiry_ID int,
	Description varchar(60),
	Order_Inquiry_ID int,
	constraint Inquiry_Action_IA_ID_PK primary key (IA_ID),
	CONSTRAINT Inquiry_Action_Order_Inquiry_ID_FK FOREIGN KEY (Order_Inquiry_ID) REFERENCES Order_Inquiry(Order_Inquiry_ID),
	CONSTRAINT Inquiry_Action_Inquiry_ID_FK FOREIGN KEY (Inquiry_ID) REFERENCES INQUIRY(Inquiry_ID)); 


/*--------------SEVENTH------------------*/

create table OrderInquiry_Action(
	OIA_ID int,
	Date_Action date,
	Adj_Ship_Amt int,
	Adj_Price_Amt int,
	Adj_QTY int,
	Adj_Rent_Amt int,
	Adj_Tax int,
	IA_ID int,
	Orderline_NO int,
	constraint OrderInquiry_Action_OIA_ID_PK primary key (OIA_ID),
	CONSTRAINT OrderInquiry_Action_IA_ID_FK FOREIGN KEY (IA_ID) REFERENCES Inquiry_Action(IA_ID),
	CONSTRAINT OrderInquiry_Action_Orderline_NO_FK FOREIGN KEY (Orderline_NO) REFERENCES ORDERLINE(Orderline_NO)); 
	

---insert scripts--
--Branch_input

use  ZeotaV1_c;
insert into BRANCH values(	100,'3415 Olanwood Court Suite 202','MANKATO','MN',5,56001);					
insert into BRANCH values(	101,'307 W. Allegheny Avenue','SAINT PAUL','MN',55101,5);					
insert into BRANCH values(	102,'145 Laywers Row','ROCHESTER','MN',55901,5);					
insert into BRANCH values(	103,'1717 Arch Street','SPRINGFIELD','IL',62701,5);					
insert into BRANCH values(	104,'200 Pennsylvania, Suite 200','WASHINGTON','DC',20009,6);					
insert into BRANCH values(	105,'14714 Main Street','DOVER','DE',19901,6);					
insert into BRANCH values(	106,'13 Federal Street P.O Box 704','TALLAHASSEE','FL',32301,6);					
insert into BRANCH values(	107,'1300 N Lake Shore Dr.','HONOLULU','HI',96813,1);					
insert into BRANCH values(	108,'warren','JUNEAU','AK',99801,2);					
insert into BRANCH values(	109,'San Street','SACRAMENTO','CA',95814,3);					
insert into BRANCH values(	110,'Stewart Sreet','CARSON CITY','NV',89701,3);					
insert into BRANCH values(	111,'1050 Conn. Ave','SALEM','OR',97301,3);					
insert into BRANCH values(	112,'300 Virginia Ave, Suite 300','PHOENIX','AZ',85003,4);		

--product
insert into product values(	110,'Microsoft','Xbox Set','Xbox,2 controller, 1 Mario game,2 memory cards',400,275,'Game',0,0,0,0,'		',0);
insert into product values(	120,'Microsoft','Xbox','Xbox',200,150,'Game',-202,30,20,0,'		',0);
insert into product values(	130,'Microsoft','Controller','Xbox controller',55,25,'Game',-308,60,40,0,'		',0);
insert into product values(	140,'Samsung','Memory Card','Xbox Memeory Card',50,25,'Game',-326,50,35,0,'		',0);
insert into product values(	150,'Sony','Mario Game','Mario Game for Xbox',50,25,'Game',-163,35,20,0,'	29-Apr-00	',0);
insert into product values(	160,'Sony','TV','42 inch Plasma TV',4995,4000,'Entertainment',5,3,5,0,'		',0);
insert into product values(	170,'Samsung','TV','42 inch Plasma TV',4495,3000,'Entertainment',5,3,5,0,'		',0);
insert into product values(	180,'Microsoft','Office','Office Professional Edition 2003',125,50,'Software',20,8,25,0,'		',0);
insert into product values(	190,'Microsoft','Windows','Windows XP Professional Edition',75,25,'Software',20,8,25,0,'		',0);
insert into product values(	200,'Microsoft','Data Input','Optical Desktop with Fingerprint Reader',50,20,'Hardware',50,20,60,0,'		',0);
--regions

insert into regions values(	1,'Hawaiian')
insert into regions values(	2,'Alaskan');
insert into regions values(	3,'Pacific');
insert into regions values(	4,'Mountain');
insert into regions values(	5,'Central');
insert into regions values(	6,'Eastern');
-- vendor

insert into vendor values(	1000,'Samsung','21 Roscoe Dr','Rochester','MN',52010,5096312121);
insert into vendor values(	1001,'Sony','109 Shepard Dr','Madison','WI',68012,3022412121);
insert into vendor values(	1002,'Microsoft','310 Simpson Ave','New York','NY',78012,6312412121);


--promotion

insert into promotion values(	100,'Xbox_2 controller_PROMOTION');
insert into promotion values(	101,'Xbox_PROMOTION');
insert into promotion values(	102,'Xbox controller_PROMOTION');
insert into promotion values(	103,'Xbox Memeory Card_PROMOTION');
insert into promotion values(	104,'Mario Game for Xbox_PROMOTION');
insert into promotion values(	105,'42 inch Plasma TV_PROMOTION');


--warehouse
insert into warehouse values(	1100,'Samsung','21 Roscoe Dr','Rochester','MN',52010,5096312121);
insert into warehouse values(	1110,'Sony','109 Shepard Dr','Madison','WI',68012,3022412121);
insert into warehouse values(	1120,'Microsoft','310 Simpson Ave','New York','NY',78012,6312412121);

--ship method
insert into Ship_Method values(	1,'ground-air');
insert into Ship_Method values(	2,'Ground');
insert into Ship_Method values(	3,'1day-air');
insert into Ship_Method values(	4,'1day');
insert into Ship_Method values(	5,'2day-air');
insert into Ship_Method values(	6,'2day');
insert into Ship_Method values(	7,'1-day');
insert into Ship_Method values(	8,'2-day');

--return category
insert into return_category values(	1,'Damaged');
insert into return_category values(	2,'Wrong Item');
insert into return_category values(	3,'Wrong Quantity');
insert into return_category values(	4,'Not satisfied');
insert into return_category values(	5,'Not properly working');
--inquiry_cateogry
insert into inquiry_category values(123456, 'Mechanical')
insert into inquiry_category values(123, 'Electrical')
insert into inquiry_category values(1234, 'Financial')
insert into inquiry_category values(12345, 'Production')
insert into inquiry_category values(12, 'General')


--training

insert into training values(001,'Sales Manager')
insert into training values(002,'Security Manager')
insert into training values(003,'Production Manager')
insert into training values(004,'General Manager')
insert into training values(005,'Customer Relation Manager')

--COMPANY
insert into company values(1100,'Chamchung',5,'3415 Olanwood Court Suite 202','MANKATO',56001,'MN');					
insert into company values(1101,'Mokia',5,'307 W. Allegheny Avenue','SAINT PAUL',55101,'MN');					
insert into company values(	1102,'Loso',5,'145 Laywers Row','ROCHESTER',55901,'MN');					
insert into company values(	1103,'Banana',5,'1717 Arch Street','SPRINGFIELD',62701,'IL');					
insert into company values(	1104,'Knights',6,'200 Pennsylvania, Suite 200','WASHINGTON',20009,'DC');					
insert into company values(	1105,'Pineapple',6,'14714 Main Street','DOVER',19901,'DE');					
insert into company values(	1106,'Coracola',6,'13 Federal Street P.O Box 704','TALLAHASSEE',32301,'FL');					
insert into company values(	1107,'Copsi',1,'1300 N Lake Shore Dr.','HONOLULU',96813,'HI');					
insert into company values(	1108,'Hapsi',2,'warren','JUNEAU',99801,'AK');					
insert into company values(	1109,'Lapsi',3,'San Street','SACRAMENTO',95814,'CA');					
insert into company values(	1110,'Chak',3,'Stewart Sreet','CARSON CITY',89701,'NV');

--certificate
INSERT INTO CERTIFICATE VALUES(1200,'Security');
INSERT INTO CERTIFICATE VALUES(1201,'Guest Relation');
INSERT INTO CERTIFICATE VALUES(1202,'Customer');
INSERT INTO CERTIFICATE VALUES(1203,'Management');
INSERT INTO CERTIFICATE VALUES(1204,'General');

--employement_status
insert into employement_status values(	1,'Active');
insert into employement_status values(	2,'Retired');
insert into employement_status values(	3,'Terminated');

--return2vendor
insert into Return2Vendor values ('	5/25/2003	',1000,130,2,10,70);
insert into Return2Vendor values('	5/26/2003	',1001,140,1,11,35);
insert into Return2Vendor values ('	5/27/2003	',1002,150,3,12,99);
insert into Return2Vendor values ('	5/28/2003	',1000,120,5,13,160);
insert into Return2Vendor values ('	5/29/2003	',1001,130,4,14,140);
insert into Return2Vendor values ('	5/30/2003	',1002,140,1,15,35);



--warehouse
insert into warehouse values(	1100,'Samsung','21 Roscoe Dr','Rochester','MN',52010,5096312121);
insert into warehouse values(	1110,'Sony','109 Shepard Dr','Madison','WI',68012,3022412121);
insert into warehouse values(	1120,'Microsoft','310 Simpson Ave','New York','NY',78012,6312412121);

--vndorPromotion
insert into Vndor_Promotion values(2000,	345,'	17-Apr-03	','	2003-06-12	',1000,100);
insert into Vndor_Promotion values(3000,	346,'	10-Apr-03	','	2003-04-30	',1001,101);
insert into Vndor_Promotion values(	4000,	347,'	15-Apr-03	','	2003-05-30	',1002,102);
insert into Vndor_Promotion values(	4,	348,'	9-Apr-03	','	2003-06-13	',1000,103);
insert into Vndor_Promotion values(	5,	349,'	7-Apr-03	','	2003-04-11	',1001,104);
insert into Vndor_Promotion values(	6,	350,'	16-Apr-03	','	2003-05-11	',1002,105);

--productpromotion
insert into Prod_Promotion values(	1,345,'	12-Apr-03	','	2003-06-12	',110,100);
insert into Prod_Promotion values(	2,346,'	1-Apr-03	','	2003-04-30	',120,101);
insert into Prod_Promotion values(	3,347,'	1-Apr-03	','	2003-05-30	',130,102);
insert into Prod_Promotion values(	4,348,'	12-Apr-03	','	2003-06-12	',140,103);
insert into Prod_Promotion values(	5,349,'	1-Apr-03	','	2003-04-30	',150,104);
insert into Prod_Promotion values(	6,350,'	1-Apr-03	','	2003-05-30	',160,105);

--vendotqtydiscount
insert into Vendor_QTYDISCOUNT values	(100,375,2,5,1000);
insert into Vendor_QTYDISCOUNT values	(101,350,6,10,1001);
insert into Vendor_QTYDISCOUNT values	(102,310,16,20,1002);
insert into Vendor_QTYDISCOUNT values	(103,330,11,15,1000);
insert into Vendor_QTYDISCOUNT values	(104,190,10,30,1001);
insert into Vendor_QTYDISCOUNT values	(105,185,31,35,1002);
insert into Vendor_QTYDISCOUNT values	(106,45,5,10,1000);
insert into Vendor_QTYDISCOUNT values	(107,40,11,15,1001);

--qtydiscount
insert into QTYDISCOUNT values(	100,375,2,5,110);
insert into QTYDISCOUNT values(	101,350,6,10,110);
insert into QTYDISCOUNT values(	102,310,16,10,110);
insert into QTYDISCOUNT values(	103,330,11,15,110);
insert into QTYDISCOUNT values(	104,190,10,30,120);
insert into QTYDISCOUNT values(	105,185,31,40,120);
insert into QTYDISCOUNT values(	106,45,5,10,140);
insert into QTYDISCOUNT values(	107,40,11,20,140);

--prodvendor
insert into PRODVENDOR values(	1093,1002,120,	'5/7/2003'	,	'5/14/2003'	,	'5/21/2003'	,	471,149);
insert into PRODVENDOR values(	1094,1002,130,	'5/7/2003'	,	'5/14/2003'	,	'5/21/2003'	,	942,32);
insert into PRODVENDOR values(	1095,1000,140,	'5/7/2003'	,	'5/14/2003'	,	'5/21/2003'	,	937,32);
insert into PRODVENDOR values(	1096,1001,150,	'5/7/2003'	,	'5/14/2003'	,	'5/21/2003'	,	471,30);
insert into PRODVENDOR values(	1097,1002,130,	'5/7/2003'	,	'5/14/2003'	,	'5/21/2003'	,	42,32);

alter table prodvendor
alter column order_date date;

alter table prodvendor
alter column actual_recvd_date date;

--backorder
insert into backorder values(	1114,110,451,	'7-May-03	');
insert into backorder values(	1115,120,902,	'7-May-03	');
insert into backorder values(	1116,130,902,	'7-May-03	');
insert into backorder values(	1117,140,451,	'7-May-03	');
insert into backorder values(	1118,150, 2 ,	'7-May-03	');
insert into backorder values(	1119,160,130,	'7-May-03	');
insert into backorder values(	1120,170,130,	'7-May-03	');
insert into backorder values(	1121,180,140,	'7-May-03	');
insert into backorder values(	1122,190,140,	'7-May-03	');
insert into backorder values(	1123,200,290,	'7-May-03	');

--vendorprice
insert into VENDORPRICE values(	103,1002,130,35,'0.1');
insert into VENDORPRICE values(	104,1000,140,35,'0.1');
insert into VENDORPRICE values(	105,1001,150,33,'0.09');
insert into VENDORPRICE values(	106,1002,120,160,'0.07');


--prod_warehouse
insert into Prod_Warehouse values(	1100,110,1000);
insert into Prod_Warehouse values(	1110,120,1500);
insert into Prod_Warehouse values(	1120,130,1002);

--ship2warehouse
insert into Ship2Warehouse values(	1100,1094,1100,'Good','	5/25/2003'	,'	5/30/2003	',1500,2);
insert into Ship2Warehouse values(	1118,1095,1101,'Good','	5/25/2003'	,'	5/30/2003	',1002,3);
insert into Ship2Warehouse values(	1112,1096,1102,'Good','	5/25/2003'	,'	5/30/2003	',1900,4);
insert into Ship2Warehouse values(	1130,1097,1103,'Good','	5/25/2003'	,'	5/30/2003	',1300,5);

--EMPLOYEE
insert into EMPLOYEE values(	1000,'Wright','Donald','300 Virginia Ave, Suite 300','MANKATO','MN',56001,1,'	10-Nov-54	',100);
insert into EMPLOYEE values(	1001,'Wright','Donald','300 Virginia Ave, Suite 300','MANKATO','MN',56001,1,'	10-Nov-54	',100);
insert into EMPLOYEE values(	1002,'Worral','Al','3567 Worthington Drive','SAINT PAUL','MN',55101,1,'	12-May-55	',100);
insert into EMPLOYEE values(	1003,'Wooton','Bruce','Union Trust','MANKATO','MN',56001,1,'	10-Nov-55	',100);
insert into EMPLOYEE values(	1004,'Widdes','Albert','307 W. Allegheny Avenue','MANKATO','MN',56001,1,'	11-May-56	',100);
insert into EMPLOYEE values(	1005,'Wehland','William C.','3415 Olanwood Court, Suite 202','MANKATO','MN',56001,1,'	9-Nov-56	',100);
insert into EMPLOYEE values(	1006,'Thomas','Peter','145 Laywers Row','ROCHESTER','MN',55901,1,'	11-May-57	',100);
insert into EMPLOYEE values(	1007,'Thomas','Patricia A.','1717 Arch Street','MANKATO','MN',56001,1,'	9-Nov-57	',100);
insert into EMPLOYEE values(	1008,'Stone','James F.','200 Pennsylvania','MANKATO','MN',56001,1,'	11-May-58	',100);
insert into EMPLOYEE values(	1009,'Stewart','John C.','14714 Main Street','MANKATO','MN',56001,1,'	9-Nov-58	',100);
insert into EMPLOYEE values(	1010,'Stansbury','Thomas','13 Federal Street P.O Box 704','MANKATO','MN',56001,1,'	11-May-59	',100);
insert into EMPLOYEE values(	1011,'Stansbury','Steward','645 Aburn Street, Suite 366','MANKATO','MN',56001,1,'	12-Jun-59	',100);
insert into EMPLOYEE values(	1012,'Somers','Bill','202 High Street','SAINT PAUL','MN',55101,1,'	9-Nov-59	',101);
insert into EMPLOYEE values(	1013,'Simmins','Steven','11160 Veirs Mill Road','SAINT PAUL','MN',55101,1,'	10-May-60	',101);
insert into EMPLOYEE values(	1014,'Ripkin','Jan','75 Federal Street','MANKATO','MN',56001,1,'	8-Nov-60	',101);
insert into EMPLOYEE values(	1015,'Reed','Donna','129 N. Washinton Avenue','SAINT PAUL','MN',55101,1,'	10-May-61	',101);
insert into EMPLOYEE values(	1016,'Prouty','Neil','1200 South Street','SAINT PAUL','MN',55101,1,'	8-Nov-61	',101);
insert into EMPLOYEE values(	1017,'Pregmon','Andrew','1700 Pennsylvania Avenue','SAINT PAUL','MN',55101,1,'	10-May-62	',101);
insert into EMPLOYEE values(	1018,'Polott','Robert','123 S. Broad Street','SAINT PAUL','MN',55101,1,'	8-Nov-62	',101);
insert into EMPLOYEE values(	1019,'Parker','Donn','1208 Pennsylvania Ave.','SAINT PAUL','MN',55101,1,'	10-May-63	',101);
insert into EMPLOYEE values(	1020,'Nilson','John','301 Charles','SAINT PAUL','MN',55101,1,'	8-Nov-63	',101);
insert into EMPLOYEE values(	1021,'Nelson','Steward','6225 Smith Avenue','ROCHESTER','MN',55901,1,'	9-May-64	',102);
insert into EMPLOYEE values(	1022,'Nabb','Claude','1201 Pennsylvania Ave','ROCHESTER','MN',55901,1,'	7-Nov-64	',102);
insert into EMPLOYEE values(	1023,'Murthy','Richard','3457 Leonard Road, Suite 200','SAINT PAUL','MN',55101,1,'	9-May-65	',102);
insert into EMPLOYEE values(	1024,'Mudd','Earl M.','740 Williams Street','ROCHESTER','MN',55901,1,'	7-Nov-65	',102);
insert into EMPLOYEE values(	1025,'Miller','Paul','One Liberty Place','SAINT PAUL','MN',55101,1,'	9-May-66	',102);
insert into EMPLOYEE values(	1026,'McMillan','Don','4910 Mass. Ave','ROCHESTER','MN',55901,1,'	7-Nov-66	',102);
insert into EMPLOYEE values(	1027,'McKissick','Doris','10451 Mill Run Ave.','SPRINGFIELD','IL',62701,1,'	9-May-67	',103);
insert into EMPLOYEE values(	1028,'Mayfield','John','410 Washington Ave.','CHICAGO','IL',60613,1,'	7-Nov-67	',103);
insert into EMPLOYEE values(	1029,'Martin','Edward','1250 Harrinton Ave.','SPRINGFIELD','IL',62701,1,'	8-May-68	',103);
insert into EMPLOYEE values(	1030,'Keting','Charles','1901 Research Blvd., Ste.220','SPRINGFIELD','IL',62701,1,'	6-Nov-68	',103);
insert into EMPLOYEE values(	1031,'Katz','Sheela','526 Poplar Street','WASHINGTON','DC',20009,1,'	8-May-69	',104);
insert into EMPLOYEE values(	1032,'Johnston','Doug','1515 Market Street 13th','WASHINGTON','DC',20009,1,'	6-Nov-69	',104);
insert into EMPLOYEE values(	1033,'Johnson','James','3677 Park Avenue','ALEXANDRIA','VA',22304,1,'	8-May-70	',104);
insert into EMPLOYEE values(	1034,'Jenkins','Dusky','100 w. Germantown Pike','WASHINGTON','DC',20009,1,'	6-Nov-70	',104);
insert into EMPLOYEE values(	1035,'Holman','James','1409 Market Boulevard','DOVER','DE',19901,1,'	8-May-71	',105);
insert into EMPLOYEE values(	1036,'Heisler','Harrison','100 W. Road, Suite 400','DOVER','DE',19901,1,'	6-Nov-71	',105);
insert into EMPLOYEE values(	1037,'Harris','Macy','245 Harrington','TALLAHASSEE','FL',32301,1,'	7-May-72	',106);
insert into EMPLOYEE values(	1038,'Hanzdo','Robert S.','200 Court Street','TALLAHASSEE','FL',32301,1,'	5-Nov-72	',106);
insert into EMPLOYEE values(	1039,'Halle','Edward','11350 McCormick Road','TALLAHASSEE','FL',32301,1,'	7-May-73	',106);
insert into EMPLOYEE values(	1040,'Geriach','David','546 Riley Court','HONOLULU','HI',96813,1,'	5-Nov-73	',107);
insert into EMPLOYEE values(	1041,'Forman','Lee','4590 Blake Street','JUNEAU','AK',99801,1,'	7-May-74	',108);
insert into EMPLOYEE values(	1042,'Farmer','Michael','4800 Hampden Lane','JUNEAU','AK',99801,1,'	5-Nov-74	',108);
insert into EMPLOYEE values(	1043,'Dupont','George','2700 Pennsylvania Avenue','SACRAMENTO','CA',95814,1,'	7-May-75	',109);
insert into EMPLOYEE values(	1044,'Dunn','Michael','305 Cheasapeke Avenue','SACRAMENTO','CA',95814,1,'	5-Nov-75	',109);
insert into EMPLOYEE values(	1045,'Doering','Willard','386 Hilltop Street','ARCADIA','CA',91006,1,'	6-May-76	',107);
insert into EMPLOYEE values(	1046,'Doering','Thomas','546 Washington','SACRAMENTO','CA',95814,1,'	4-Nov-76	',109);
insert into EMPLOYEE values(	1047,'Constable','Ramond','2 Hopkins Plaza, Suite 107','SACRAMENTO','CA',95814,1,'	6-May-77	',109);
insert into EMPLOYEE values(	1048,'Colson','Eugenia','409 Washington Ave.','SACRAMENTO','CA',95814,1,'	4-Nov-77	',109);
insert into EMPLOYEE values(	1049,'Claggett','Edward','14 Dupont Circle','BAKERSFIELD','CA',93308,1,'	6-May-78	',109);
insert into EMPLOYEE values(	1050,'Bullit','Stephan','Marys Avenue','SACRAMENTO','CA',95814,1,'	4-Nov-78	',109);
insert into EMPLOYEE values(	1051,'Bond','Jullian','100 N. Charles Street','SACRAMENTO','CA',95814,1,'	6-May-79	',109);
insert into EMPLOYEE values(	1052,'Worral','Stefan','100 N. Charles Street','CARSON CITY','NV',89701,1,'	4-Nov-79	',110);
insert into EMPLOYEE values(	1053,'Pregmon','Agnes','100 w. Germantown Pike','CALIENTE','NV',89008,1,'	5-May-80	',110);
insert into EMPLOYEE values(	1054,'Martin','Al','100 W. Road, Suite 400','CARSON CITY','NV',89701,1,'	3-Nov-80	',110);
insert into EMPLOYEE values(	1055,'Heisler','Albert','102 W. Pennsylavania Ave','CARSON CITY','NV',89701,1,'	5-May-81	',110);
insert into EMPLOYEE values(	1056,'Murthy','Andrew','10451 Mill Run Ave.','LAS VEGAS','NV',89106,1,'	3-Nov-81	',110);
insert into EMPLOYEE values(	1057,'Colson','Bill','1050 Conn. Ave','CARSON CITY','NV',89701,1,'	5-May-82	',110);
insert into EMPLOYEE values(	1058,'Jenkins','Bruce','11160 Veirs Mill Road','CARSON CITY','NV',89701,1,'	3-Nov-82	',110);
insert into EMPLOYEE values(	1059,'Beckley','Catherine','11350 McCormick Road','SALEM','OR',97301,1,'	5-May-82	',111);
insert into EMPLOYEE values(	1060,'Bixler','Charles','1200 South Street','SALEM','OR',97301,1,'	3-Nov-81	',111);
insert into EMPLOYEE values(	1061,'Harris','Claude','1201 Pennsylvania Ave','ALOHA','OR',97007,1,'	5-May-81	',111);
insert into EMPLOYEE values(	1062,'Blazek-White','David','1208 Pennsylvania Ave.','SALEM','OR',97301,1,'	3-Nov-80	',111);
insert into EMPLOYEE values(	1063,'Somers','Don','123 S. Broad Street','LINCOLN CITY','OR',97367,1,'	5-May-80	',111);
insert into EMPLOYEE values(	1064,'Halle','Donald','1250 Harrinton Ave.','PHOENIX','AZ',85003,1,'	4-Nov-79	',112);
insert into EMPLOYEE values(	1065,'Parker','Donn','129 N. Washinton Avenue','PHOENIX','AZ',85003,1,'	6-May-79	',112);
insert into EMPLOYEE values(	1066,'Bond','Donna','13 Federal Street P.O Box 704','PHOENIX','AZ',85003,1,'	4-Nov-78	',112);
insert into EMPLOYEE values(	1067,'Adams','Doris','1345 Rice Blvd.','PHOENIX','AZ',85003,1,'	6-May-78	',112);

--Customer
insert into CUSTOMER values(	1000,'Jake','Roerig','16 Skyline Drive','Mankato','MN',56001,5,507-344-4567,1000,0,100);
insert into CUSTOMER values(	1001,'Case','Steve','101 michigan','New Ulm','MN',56023,5,507-344-4568,2500,5000,101);
insert into CUSTOMER values(	1003,'Aslam','Kashif','762 Stadium Rd','Mankato','MN',56001,5,507-344-4569,0,0,102);
insert into CUSTOMER values(	1006,'Brin','Laral','52 Wacker','Chicago','IL',60626,5,507-344-4570,0,0,103);
insert into CUSTOMER values(	1023,'Maria','Jensen','10 State','New Ulm','MN',56023,5,507-344-4571,2500,5000,100);
insert into CUSTOMER values(	1024,'Aslam','Muhammad','12 stadium','Madison','WI',54003,5,507-344-4572,9000,0,101);
insert into CUSTOMER values(	1025,'George','Colony','314 Maywood','Mankato','MI',20000,6,507-344-4573,0,0,103);
insert into CUSTOMER values(	1029,'Jake','Lara','214 golf','New York','NY',72314,6,507-344-4574,60000,0,104);
insert into CUSTOMER values(	1030,'Somers','Peter','123 S. Broad Street','HARTFORD','CT',6103,6,507-344-4575,0,0,105);
insert into CUSTOMER values(	1031,'Pregmon','Patricia A.','100 w. Germantown Pike','WASHINGTON','DC',20009,6,507-344-4576,0,0,106);
insert into CUSTOMER values(	1032,'Farmer','James F.','3457 Leonard Road, Suite 200','DOVER','DE',19901,6,507-344-4577,0,0,104);
insert into CUSTOMER values(	1033,'Prouty','John C.','2250 Potts Point Road','TALLAHASSEE','FL',32301,6,507-344-4578,0,0,104);
insert into CUSTOMER values(	1034,'Mudd','Thomas','Marys Avenue','ATLANTA','GA',30303,6,507-344-4579,0,0,104);
insert into CUSTOMER values(	1035,'Katz','Neil','51 Monroe Street','INDIANAPOLIS','IN',46201,6,507-344-4580,0,0,105);
insert into CUSTOMER values(	1036,'Claggett','Robert','14714 Main Street','FRANKFORT','KY',40601,6,507-344-4581,0,0,106);
insert into CUSTOMER values(	1037,'Bixler','John','Metropolitan Square','BOSTON','MA',2108,6,507-344-4582,0,0,104);
insert into CUSTOMER values(	1038,'Dunn','Steward','1700 Pennsylvania Avenue','ANNAPOLIS','MD',21403,6,507-344-4583,0,0,105);
insert into CUSTOMER values(	1039,'Stansbury','Claude','645 Aburn Street, Suite 366','AUGUSTA','ME',4330,6,507-344-4584,0,0,106);
insert into CUSTOMER values(	1040,'Mayfield','Richard','4910 Mass. Ave','LANSING','MI',48906,6,507-344-4585,0,0,104);
insert into CUSTOMER values(	1041,'Beckley','John','11350 McCormick Road','RALEIGH','NC',27601,6,507-344-4586,0,0,105);
insert into CUSTOMER values(	1042,'Murthy','Sheela','10451 Mill Run Ave.','CONCORD','NH',3301,6,507-344-4587,0,0,106);
insert into CUSTOMER values(	1043,'Worral','Doug','100 N. Charles Street','TRENTON','NJ',8608,6,507-344-4588,0,0,104);
insert into CUSTOMER values(	1044,'Wright','James','2 Hopkins Plaza, Suite 107','ALBANY','NY',12202,6,507-344-4589,0,0,105);
insert into CUSTOMER values(	1045,'Stone','Harrison','200 W. Pennsylvania','COLUMBUS','OH',43201,6,507-344-4590,0,0,106);
insert into CUSTOMER values(	1046,'Martin','Edward','100 W. Road, Suite 400','HARRISBURG','PA',17101,6,507-344-4591,0,0,104);
insert into CUSTOMER values(	1047,'Heisler','David','102 W. Pennsylavania Ave','PROVIDENCE','RI',2903,6,507-344-4592,0,0,105);
insert into CUSTOMER values(	1048,'Thomas','Lee','409 Washington Ave.','COLUMBIA','SC',29201,6,507-344-4593,0,0,106);
insert into CUSTOMER values(	1049,'Keting','Thomas','202 High Street','RICHMOND','VA',23219,6,507-344-4594,0,0,104);
insert into CUSTOMER values(	1050,'Simmins','Ramond','526 Poplar Street','MONTPELIER','VT',5602,6,507-344-4595,0,0,105);
insert into CUSTOMER values(	1051,'Bixler','Stephan','1200 South Street','CHARLESTON','WV',25301,6,507-344-4596,0,0,106);
insert into CUSTOMER values(	1052,'Albright','Westin','546 Washington','RALEIGH','NC',27601,6,507-344-4597,0,0,104);
insert into CUSTOMER values(	1053,'Dupont','Stacy','740 Williams Street','CONCORD','NH',3301,6,507-344-4598,0,0,105);
insert into CUSTOMER values(	1054,'Ripkin','Howard','300 Virginia Ave, Suite 300','TRENTON','NJ',8608,6,507-344-4599,0,0,106);
insert into CUSTOMER values(	1055,'Stansbury','Michael','13 Federal','ALBANY','NY',12202,6,507-344-4600,0,0,104);
insert into CUSTOMER values(	1058,'Johny','John','2250 Potts Point Road','LITTLE ROCK','AR',72201,5,507-344-4601,4000,0,102);
insert into CUSTOMER values(	1059,'Geriach','Donald','Box 2009 Unio','MONTGOMERY','AL',36107,5,507-344-4602,0,0,103);
insert into CUSTOMER values(	1060,'Doering','Al','1515 Market Street 13th','LITTLE ROCK','AR',72201,5,507-344-4603,0,0,100);
insert into CUSTOMER values(	1061,'Widdes','Steven','4800 Hampden Lane','DES MOINES','IA',50309,5,507-344-4604,0,0,101);
insert into CUSTOMER values(	1062,'McMillan','Donna','1901 Research Blvd., Ste.220','SPRINGFIELD','IL',62701,5,507-344-4605,0,0,102);
insert into CUSTOMER values(	1063,'Polott','Andrew','15400 Calhoun Drive Suite 140','TOPEKA','KS',66603,5,507-344-4606,0,0,103);
insert into CUSTOMER values(	1064,'Jenkins','Donn','11160 Veirs Mill Road','MADISON','WI',53703,5,507-344-4607,0,0,100);
insert into CUSTOMER values(	1065,'Colson','Earl M.','1050 Conn. Ave','SAINT PAUL','MN',55101,5,507-344-4608,0,0,101);
insert into CUSTOMER values(	1066,'Allen','Paul','14 Dupont Circle','JEFFERSON CITY','MO',65101,5,507-344-4609,0,0,102);
insert into CUSTOMER values(	1067,'Harris','Don','1201 Pennsylvania Ave','JACKSON','MS',39201,5,507-344-4610,0,0,103);
insert into CUSTOMER values(	1068,'Halle','Edward','1250 Harrinton Ave.','BISMARCK','ND',58501,5,507-344-4611,0,0,100);
insert into CUSTOMER values(	1069,'Wehland','Charles','3677 Park Avenue','LINCOLN','NE',68502,5,507-344-4612,0,0,101);
insert into CUSTOMER values(	1070,'Nelson','Macy','410 Washington Ave.','OKLAHOMA CITY','OK',73102,5,507-344-4613,0,0,102);
insert into CUSTOMER values(	1071,'Nilson','George','6225 Smith Avenue','NASHVILLE','TN',37201,5,507-344-4614,0,0,103);
insert into CUSTOMER values(	1072,'Bond','Michael','13 Federal 704','MADISON','WI',53703,5,507-344-4615,0,0,100);
insert into CUSTOMER values(	1073,'Nabb','Edward','145 Laywers Row','MADISON','WI',53703,5,507-344-4616,0,0,101);
insert into CUSTOMER values(	1074,'Johnson','William','546 Riley Court','SAINT PAUL','MN',55101,5,507-344-4617,0,0,102);
insert into CUSTOMER values(	1075,'Forman','Judy','245 Harrington 300','JEFFERSON CITY','MO',65101,5,507-344-4618,0,0,103);
insert into CUSTOMER values(	1076,'Thomas','Catherine','4590 Blake Street','JACKSON','MS',39201,5,507-344-4619,0,0,100);
insert into CUSTOMER values(	1077,'Miller','William','386 Hilltop Street','BISMARCK','ND',58501,5,507-344-4620,0,0,101);
insert into CUSTOMER values(	1078,'Johnston','Agnes','2700 Pennsylvania Avenue','LINCOLN','NE',68502,5,507-344-4621,0,0,102);
insert into CUSTOMER values(	1079,'McKissick','Bill','91 Maple Drive, Suite 205','HONOLULU','HI',96813,1,507-344-4622,0,0,107);
insert into CUSTOMER values(	1080,'Nagal','Stefan','75 Federal Street','JUNEAU','AK',99801,2,507-344-4623,0,0,108);
insert into CUSTOMER values(	1081,'Doering','Albert','One Liberty Place','SACRAMENTO','CA',95814,3,507-344-4624,0,0,109);
insert into CUSTOMER values(	1082,'Holman','Dusky','301Charles Street','CARSON CITY','NV',89701,3,507-344-4625,0,0,110);
insert into CUSTOMER values(	1083,'Hanzdo','Robert S.','307 W. Allegheny Avenue','SALEM','OR',97301,3,507-344-4626,0,0,111);
insert into CUSTOMER values(	1084,'Wooton','Eugenia','200 Court Street','OLYMPIA','WA',98501,3,507-344-4627,0,0,111);
insert into CUSTOMER values(	1085,'Dunn','Michael','305 Cheasapeke Avenue','CARSON CITY','NV',89701,3,507-344-4628,0,0,110);
insert into CUSTOMER values(	1086,'Reed','Bruce','1717 Arch Street','PHOENIX','AZ',85003,4,507-344-4629,0,0,112);
insert into CUSTOMER values(	1087,'Bullit','William C.','18thLogan Square','DENVER','CO',80202,4,507-344-4630,0,0,113);
insert into CUSTOMER values(	1088,'Stewart','Jan','3415 Olanwood Court, Suite 202','BOISE','ID',83702,4,507-344-4631,0,0,114);
insert into CUSTOMER values(	1089,'Blazek-White','Doris','1208 Pennsylvania Ave.','HELENA','MT',59601,4,507-344-4632,0,0,112);
insert into CUSTOMER values(	1090,'Constable','James','3567 Worthington Drive','SANTA FE','NM',87505,4,507-344-4633,0,0,113);
insert into CUSTOMER values(	1091,'Wyatt','Michael','305 Cheasapeke Avenue','PIERRE','SD',57501,4,507-344-4634,0,0,114);
insert into CUSTOMER values(	1092,'Alan','Hubert','1409 Market Boulevard','HELENA','MT',59601,4,507-344-4635,0,0,114);
insert into CUSTOMER values(	1093,'Bixler','Neil','51 Monroe Street','SANTA FE','NM',87505,4,507-344-4636,0,0,114);
insert into CUSTOMER values(	1094,'Michael','Nagal','4910 Mass. Ave','HONOLULU','HI',96813,1,507-344-4637,0,0,107);
insert into CUSTOMER values(	1095,'Bullit','Murthy','100 N. Charles Street','HONOLULU','HI',96813,1,507-344-4638,0,0,107);
insert into CUSTOMER values(	1096,'Neil','Stone','100 W. Road, Suite 400','HONOLULU','HI',96813,1,507-344-4639,0,0,107);
insert into CUSTOMER values(	1097,'Steward','Thomas','202 High Street','HONOLULU','HI',96813,1,507-344-4640,0,0,107);
insert into CUSTOMER values(	1098,'John','Bixler','546 Washington','HONOLULU','HI',96813,1,507-344-4641,0,0,107);
insert into CUSTOMER values(	1099,'James','Ripkin','13 Federal Street P.O Box 704','JUNEAU','AK',99801,2,507-344-4642,0,0,108);
insert into CUSTOMER values(	1100,'David','McKissick','123 S. Broad Street','JUNEAU','AK',99801,2,507-344-4643,0,0,108);
insert into CUSTOMER values(	1101,'Ramond','Bruce','1208 Pennsylvania Ave.','JUNEAU','AK',99801,2,507-344-4644,0,0,108);
insert into CUSTOMER values(	1102,'Parker','Willard','129 N. Washinton Avenue','SALT LAKE CITY','UT',84101,4,507-344-4645,0,0,112);
insert into CUSTOMER values(	1103,'Adams','Jullian','1345 Rice Blvd.','CHEYENNE','WY',82001,4,507-344-4646,0,0,113);
insert into CUSTOMER values(	1104,'Mark','Chanderpaul','1902 Warren Street','OLYMPIA','WA',98501,3,507-344-4647,0,0,112);
insert into CUSTOMER values(	1105,'Andrew','Pagon','133 East Drive','PHOENIX','AZ',85003,4,507-344-4648,0,0,112);
insert into CUSTOMER values(	1106,'Mark','Bravo','215 Strawberry Rd','COLUMBIA','SC',29201,6,507-344-4649,0,0,105);
insert into CUSTOMER values(	1107,'Mark','Browne','EMadison st','CHARLESTON','WV',25301,6,507-344-4650,0,0,105);
insert into CUSTOMER values(	1108,'Peter','Collins','215 Mcdaniel St','TRENTON','NJ',8608,6,507-344-4651,0,0,106);
insert into CUSTOMER values(	1109,'Haag','King','Virgin Street','RALEIGH','NC',27601,6,507-344-4652,0,0,106);
insert into CUSTOMER values(	1110,'Hagen','Sehwag','1404 Brooke','Mankato','MN',56001,5,507-344-4653,0,0,100);
insert into CUSTOMER values(	1111,'Sachin','Tendulkar','Palm Court Road','New Ulm','MN',56023,5,507-344-4654,0,0,100);
insert into CUSTOMER values(	1112,'Sourav','Ganguly','Archard Street','LITTLE ROCK','AR',72201,5,507-344-4655,0,0,101);
insert into CUSTOMER values(	1113,'Rahul','Dravid','Mc Donald Street','MADISON','WI',53703,5,507-344-4656,0,0,100);
insert into CUSTOMER values(	1114,'Yuvraj','Singh','Maryland Avenue','BISMARCK','ND',58501,5,507-344-4657,0,0,101);
insert into CUSTOMER values(	1115,'Rhody','Kaif','Portland Avenue','MADISON','WI',53703,5,507-344-4658,0,0,101);
insert into CUSTOMER values(	1116,'Rill','Dhoni','1402 West Drive','JACKSON','MS',39201,5,507-344-4659,0,0,101);
insert into CUSTOMER values(	1117,'Harbhajan','Singh','Old Shell Road','WASHINGTON','DC',20009,6,507-344-4660,0,0,105);
insert into CUSTOMER values(	1118,'Michael','Don','Mill Road','FRANKFORT','KY',40601,6,507-344-4661,0,0,105);
insert into CUSTOMER values(	1119,'Umair','Khan','HighLand Hill','New Ulm','MN',56023,5,507-344-4662,0,0,100);
insert into CUSTOMER values(	1120,'Salman','Butt','Calonial Manor','LITTLE ROCK','AR',72201,5,507-344-4663,0,0,100);
insert into CUSTOMER values(	1121,'Kamran','Akmal','Mason Avenue','SAINT PAUL','MN',55101,5,507-344-4664,0,0,101);
insert into CUSTOMER values(	1122,'Shoaib','Malik','Bombay Street','LINCOLN','NE',68502,5,507-344-4665,0,0,100);
insert into CUSTOMER values(	1123,'Yousuf','Youhana','Beasant Road','JUNEAU','AK',99801,2,507-344-4666,0,0,108);
insert into CUSTOMER values(	1124,'Inzamam','Haq','RedFort Street','SACRAMENTO','CA',95814,3,507-344-4667,0,0,110);
insert into CUSTOMER values(	1125,'Mohammad','Hafeez','140 East  Drive','CARSON CITY','NV',89701,3,507-344-4668,0,0,111);
insert into CUSTOMER values(	1126,'Abdul','Razzaq','67 Morocco Street','SALT LAKE CITY','UT',84101,4,507-344-4669,0,0,112);
insert into CUSTOMER values(	1127,'Shahid','Afridi','Andrew Mall Road','DENVER','CO',80202,4,507-344-4670,0,0,113);
insert into CUSTOMER values(	1128,'Mohammad','Sami','51 Monroe Street','SANTA FE','NM',87505,4,507-344-4671,0,0,112);
insert into CUSTOMER values(	1194,'Vivian','Richards','Airport Boulevard','TALLAHASSEE','FL',32301,6,507-344-4672,0,0,106);
insert into CUSTOMER values(	1195,'Jim','Nel','91 Maple Drive, Suite 205','HONOLULU','HI',96813,1,507-344-4673,0,0,107);
insert into CUSTOMER values(	1196,'Mark','Ntini','Brook Street','HONOLULU','HI',96813,1,507-344-4674,0,0,107);
insert into CUSTOMER values(	1197,'Jack','Kallis','Walnut Street','JUNEAU','AK',99801,2,507-344-4675,0,0,108);
insert into CUSTOMER values(	1198,'Allen','Zondeki','Walnut Street','JUNEAU','AK',99801,2,507-344-4676,0,0,108);
insert into CUSTOMER values(	1199,'Nick','Boje','Mill Road','HELENA','MT',59601,4,507-344-4677,0,0,112);
insert into CUSTOMER values(	1200,'Gabbert','Hinds','Mount Pleasant Road','BOISE','ID',83702,4,507-344-4678,0,0,113);
insert into CUSTOMER values(	1201,'Gelle','Gayle','RussellWelle Street','PIERRE','SD',57501,4,507-344-4679,0,0,112);
insert into CUSTOMER values(	1202,'Goldy','Sarwan','Thatcher Street','CARSON CITY','NV',89701,3,507-344-4680,0,0,110);
insert into CUSTOMER values(	1203,'Brain','Lara','Clover Hill','CARSON CITY','NV',89701,3,507-344-4681,0,0,111);

--REGION_STATE

insert into region_state values(	'Alabama','AL','SARALAND',36571,5);
insert into region_state values(	'Arkansas','AR','ADONA',72001,5);
insert into region_state values(	'Alaska','AK','AKHIOK',99615,2);
insert into region_state values(	'California','CA','DOWNEY',90241,3);
insert into region_state values(	'Arizona','AZ','ALPINE',85920,4);
insert into region_state values(	'Colorado','CO','AGATE',80101,4);
insert into region_state values(	'Connecticut','CT','PAWCATUCK',6379,6);
insert into region_state values(	'District Of Columbia','DC','PENTAGON',20301,6);
insert into region_state values(	'Delaware','DE','BEAR',19701,6);
insert into region_state values(	'Florida','FL','AIRPORT',34622,6);
insert into region_state values(	'Georgia','GA','GRANTVILLE',30220,6);
insert into region_state values(	'Hawaii','HI','AIEA',96701,1);
insert into region_state values(	'Iowa','IA','ACKLEY',50601,5);
insert into region_state values(	'Idaho','ID','CARMEN',83462,4);
insert into region_state values(	'Illinois','IL','ABBOTT PARK',60064,5);
insert into region_state values(	'Indiana','IN','PARKER CITY',47368,6);
insert into region_state values(	'Kansas','KS','ABBYVILLE',67510,5);
insert into region_state values(	'Kentucky','KY','AARON',42601,6);
insert into region_state values(	'Louisiana','LA','ABITA SPRINGS',70420,5);
insert into region_state values(	'Massachusetts','MA','ABINGTON',2351,6);
insert into region_state values(	'Maine','ME','CORINNA',4928,6);
insert into region_state values(	'Michigan','MI','ADA',49301,6);
insert into region_state values(	'Maryland','MD','ABELL',20606,6);
insert into region_state values(	'Minnesota','MN','BRANDON',56315,5);
insert into region_state values(	'Missouri','MO','ADRIAN',64720,5);
insert into region_state values(	'Mississippi','MS','CRUGER',38924,5);
insert into region_state values(	'Montana','MT','ABSAROKEE',59001,4);
insert into region_state values(	'North Carolina','NC','ABERDEEN',28315,6);
insert into region_state values(	'North Dakota','ND','ABSARAKA',58002,5);
insert into region_state values(	'Nebraska','NE','AVOCA',68307,5);
insert into region_state values(	'New Jersey','NJ','SPRING LAKE',7762,6);
insert into region_state values(	'New Mexico','NM','ABIQUIU',87510,4);
insert into region_state values(	'Nevada','NV','ALAMO',89001,3);
insert into region_state values(	'New York','NY','ACCORD',12404,6);
insert into region_state values(	'New Hampshire','NH','ALLENSTOWN',3275,6);
insert into region_state values(	'Ohio','OH','ABERDEEN',45101,6);
insert into region_state values(	'Oklahoma','OK','ELMWOOD',73932,5);
insert into region_state values(	'Oregon','OR','ADAMS',97810,3);
insert into region_state values(	'Pennsylvania','PA','AARONSBURG',16820,6);
insert into region_state values(	'South Dakota','SD','MANSFIELD',57460,4);
insert into region_state values(	'Tennessee','TN','ADAMS',37010,5);
insert into region_state values(	'Texas','TX','ABBOTT',76621,5);
insert into region_state values(	'Rhode Island','RI','ASHAWAY',2804,6);
insert into region_state values(	'South Carolina','SC','ABBEVILLE',29620,6);
insert into region_state values(	'Washington','WA','BUCKLEY',98321,3);
insert into region_state values(	'Wisconsin','WI','ABBOTSFORD',54405,5);
insert into region_state values(	'West Virginia','WV','ABRAHAM',25918,6);
insert into region_state values(	'Utah','UT','ALPINE',84004,4);
insert into region_state values(	'Wyoming','WY','ACME',82839,4);
insert into region_state values(	'Virgina','VA','ABINGDON',24210,6);
insert into region_state values(	'Vermont','VT','ADAMANT',5640,6);

-- TAX
insert into TAX values(	101,'NEW YORK',0.077306618);
insert into TAX values(	134,'Alabama',0.077306618);
insert into TAX values(	102,'Arkansas',0);
insert into TAX values(	103,'Alaska',0.079650877);
insert into TAX values(	104,'California',0.04);
insert into TAX values(	105,'Arizona',0.07117549);
insert into TAX values(	106,'Colorado',0);
insert into TAX values(	107,'Connecticut',0);
insert into TAX values(	108,'District Of Columbia',0.067139394);
insert into TAX values(	109,'Delaware',0);
insert into TAX values(	110,'Florida',0.04);
insert into TAX values(	111,'Georgia',0.070011099);
insert into TAX values(	112,'Hawaii',0.05);
insert into TAX values(	113,'Iowa',0.06);
insert into TAX values(	114,'Idaho',0.058971444);
insert into TAX values(	115,'Illinois',0.06);
insert into TAX values(	116,'Indiana',0.069162196);
insert into TAX values(	117,'Kansas',0);
insert into TAX values(	118,'Kentucky',0.045);
insert into TAX values(	119,'Louisiana',0.061417864);
insert into TAX values(	120,'Massachusetts',0.066257571);
insert into TAX values(	121,'Maine',0.065547315);
insert into TAX values(	122,'Michigan',0.132776316);
insert into TAX values(	123,'Maryland',0.06);
insert into TAX values(	124,'Minnesota',0.066248394);
insert into TAX values(	125,'Missouri',0);
insert into TAX values(	126,'Mississippi',0.06);
insert into TAX values(	127,'Montana',0);
insert into TAX values(	128,'North Carolina',0.058960829);
insert into TAX values(	129,'North Dakota',0.011199143);
insert into TAX values(	130,'Nebraska',0);
insert into TAX values(	131,'New Jersey',0.051805556);
insert into TAX values(	132,'New Mexico',0);
insert into TAX values(	133,'Nevada',0.07);
insert into TAX values(	135,'New Hampshire',0.052255521);
insert into TAX values(	136,'Ohio',0.050258065);
insert into TAX values(	137,'Oklahoma',0.05);
insert into TAX values(	138,'Oregon',0.067557027);
insert into TAX values(	139,'Pennsylvania',0.054117886);
insert into TAX values(	140,'South Dakota',0.060182292);
insert into TAX values(	141,'Tennessee',0.070202068);
insert into TAX values(	142,'Texas',0.061258341);
insert into TAX values(	143,'Rhode Island',0.04);
insert into TAX values(	144,'South Carolina',0.057342488);
insert into TAX values(	145,'Washington',0.081597636);
insert into TAX values(	146,'Wisconsin',0.05);
insert into TAX values(	147,'West Virginia',0.09375);
insert into TAX values(	148,'Utah',0.049812327);
insert into TAX values(	149,'Wyoming',0.056406619);
insert into TAX values(	150,'Virgina',0.059375);
insert into TAX values(	151,'Vermont',0.069769031);


--ORDERS
insert into ORDERS values(	100,	1004,	100,	1,	'y',62042,4067,3102,69211,1023,'15-Apr-99','15-Apr-99',1100);		
insert into ORDERS values(	110,	1005,	100,	6,	'y',156150,10235,12492,178877,1060,'3-Jan-99','8-Jan-99',1101);		
insert into ORDERS values(	1005,	1005,	100,	3,	'y',284500,17070,28450,330020,1072,'7-Jul-99','12-Jul-99',1102);		
insert into ORDERS values(	1006,	1005,	100,	3,	'y',30000,1966,3000,34966,1076,'1-Apr-99','26-Apr-99',1103);		
insert into ORDERS values(	1007,	1005,	100,	2,	'n',39600,0,1980,41580,1000,'27-Apr-99','2-May-99',1104);		
insert into ORDERS values(	1008,	1005,	100,	5,	'n',34650,0,2772,37422,1064,'5-Jul-99','10-Jul-99',1105);		
insert into ORDERS values(	1023,	1005,	100,	5,	'y',7130,467,570,8168,1068,'3-Mar-99','7-Mar-99',1106);		
insert into ORDERS values(	1025,	1005,	100,	3,	'y',165120,10823,16512,192455,1064,'29-Apr-99','4-May-99',1107);		
insert into ORDERS values(	1026,	1005,	100,	2,	'n',79875,0,0,79875,1060,'30-Apr-99','5-May-99',1108);		
insert into ORDERS values(	1027,	1005,	100,	2,	'n',17820,0,0,17820,1068,'6-Apr-99','9-Apr-99',1109);		

--STATE_CAPITAL
insert into state_capital values(	'HONOLULU','Alabama',96813,1);	
insert into state_capital values(	'JUNEAU','Arkansas',99801,2);	
insert into state_capital values(	'SACRAMENTO','Alaska',95814,3);	
insert into state_capital values(	'CARSON CITY','California',89701,3);	
insert into state_capital values(	'SALEM','Arizona',97301,3);	
insert into state_capital values(	'OLYMPIA','Colorado',98501,3);	
insert into state_capital values(	'PHOENIX','Connecticut',85003,4);	
insert into state_capital values(	'DENVER','District Of Columbia',80202,4);	
insert into state_capital values(	'BOISE','Delaware',83702,4);	
insert into state_capital values(	'HELENA','Florida',59601,4);	
insert into state_capital values(	'SANTA FE','Georgia',87505,4);	
insert into state_capital values(	'PIERRE','Hawaii',57501,4);	
insert into state_capital values(	'SALT LAKE CITY','Iowa',84101,4);	
insert into state_capital values(	'CHEYENNE','Idaho',82001,4);	
insert into state_capital values(	'MONTGOMERY','Illinois',36107,5);	
insert into state_capital values(	'LITTLE ROCK','Indiana',72201,5);	
insert into state_capital values(	'DES MOINES','Kansas',50309,5);	
insert into state_capital values(	'SPRINGFIELD','Kentucky',62701,5);	
insert into state_capital values(	'TOPEKA','Louisiana',66603,5);	
insert into state_capital values(	'BATON ROUGE','Massachusetts',70801,5);	
insert into state_capital values(	'SAINT PAUL','Maine',55101,5);	
insert into state_capital values(	'JEFFERSON CITY','Michigan',65101,5);	
insert into state_capital values(	'JACKSON','Maryland',39201,5);	
insert into state_capital values(	'BISMARCK','Minnesota',58501,5);	
insert into state_capital values(	'LINCOLN','Missouri',68502,5);	
insert into state_capital values(	'OKLAHOMA CITY','Mississippi',73102,5);	
insert into state_capital values(	'NASHVILLE','Montana',37201,5);	
insert into state_capital values(	'AUSTIN','North Carolina',78701,5);	
insert into state_capital values(	'MADISON','North Dakota',53703,5);	
insert into state_capital values(	'HARTFORD','Nebraska',6103,6);	
insert into state_capital values(	'WASHINGTON','New Jersey',20009,6);	
insert into state_capital values(	'DOVER','New Mexico',19901,6);	
insert into state_capital values(	'TALLAHASSEE','Nevada',32301,6);	
insert into state_capital values(	'ATLANTA','New York',30303,6);	
insert into state_capital values(	'INDIANAPOLIS','New Hampshire',46201,6);	
insert into state_capital values(	'FRANKFORT','Ohio',40601,6);	
insert into state_capital values(	'BOSTON','Oklahoma',2108,6);	
insert into state_capital values(	'ANNAPOLIS','Oregon',21403,6);	
insert into state_capital values(	'AUGUSTA','Pennsylvania',4330,6);	
insert into state_capital values(	'LANSING','South Dakota',48906,6);	
insert into state_capital values(	'RALEIGH','Tennessee',27601,6);	
insert into state_capital values(	'CONCORD','Texas',3301,6);	
insert into state_capital values(	'TRENTON','Rhode Island',8608,6);	
insert into state_capital values(	'ALBANY','South Carolina',12202,6);	
insert into state_capital values(	'COLUMBUS','Washington',43201,6);	
insert into state_capital values(	'HARRISBURG','Wisconsin',17101,6);	
insert into state_capital values(	'PROVIDENCE','West Virginia',2903,6);	
insert into state_capital values(	'COLUMBIA','Utah',29201,6);	
insert into state_capital values(	'RICHMOND','Wyoming',23219,6);	
insert into state_capital values(	'MONTPELIER','Virgina',5602,6);	
insert into state_capital values(	'CHARLESTON','Vermont',25301,6);	

--ORDERLINE


insert into ORDERLINE values	(1002,140,25,110);	
insert into ORDERLINE values	(1004,140,25,110);
insert into ORDERLINE values	(1005,140,1,100);
insert into ORDERLINE values	(1006,130,130,110);
insert into ORDERLINE values	(1007,120,800,110);
insert into ORDERLINE values	(1024,110,500,1005);
insert into ORDERLINE values	(1025,120,700,1005);
insert into ORDERLINE values	(1026,140,750,1006);
insert into ORDERLINE values	(1027,130,900,1007);

--RETURNPROD


insert into returnprod values(	1004,1,3,'15-May-99',50,1);
insert into returnprod values(	1005,10,4,'16-Jan-00',1000,2);
insert into returnprod values(	1106,5,5,'16-Jan-00',500,3);
insert into returnprod values(	1007,2,6,'16-Jan-00',200,5);
insert into returnprod values(	1024,1,7,'16-Jan-00',100,2);
insert into returnprod values(	1025,2,8,'16-Jan-00',200,1);
insert into returnprod values(	1026,8,9,'16-Jan-00',800,4);
insert into returnprod values(	1027,12,10,'16-Jan-00',3140,3);


-- return_sales_comission

insert into Return_Sales_Commission values(	1005,3,12);
insert into Return_Sales_Commission values(	1005,4,13);
insert into Return_Sales_Commission values(	1005,6,15);
insert into Return_Sales_Commission values(	1005,7,16);
insert into Return_Sales_Commission values(	1005,8,17);
insert into Return_Sales_Commission values(	1005,9,18);
insert into Return_Sales_Commission values(	1005,10,19);
insert into Return_Sales_Commission values(	1004,11,20);

--Position

insert into position values(	1,'CEO');	
insert into position values(	2,'Branch Manager');	
insert into position values(	3,'Sales Manager');	
insert into position values(	4,'Sales Representative');	
insert into position values(	5,'Customer Service Manager');	
insert into position values(	6,'Customer Service');	
insert into position values(	7,'Technician');	
insert into position values(	8,'Programmer');	
insert into position values(	9,'Accountant');

--Employee_Position
	 alter table Employee_position drop column start_date;
	 alter table Employee_position drop column end_date;
	 Alter table Employee_position ADD Description varchar(25);
insert into employee_position values(	100,1,1000,'CEO');
insert into employee_position values(	101,2,1001,'Branch Manager');
insert into employee_position values(	102,3,1002,'Sales Manager');
insert into employee_position values(	103,4,1003,'Sales Representative');
insert into employee_position values(	104,5,1004,'Customer Service Manager');
insert into employee_position values(	105,6,1005,'Customer Service');
insert into employee_position values(	106,7,1006,'Technician');
insert into employee_position values(	107,8,1007,'Programmer');
insert into employee_position values(	108,9,1008,'Accountant');

--department
insert into department values (	1010,'Accounting','1255 Harrinton Ave.','MANKATO','MN',87458);
insert into department values (	1011,'Sales','300 Virginia Ave, Suite 300','MANKATO','MN',87459);
insert into department values (	1012,'Management','3567 Worthington Drive','SAINT PAUL','MN',87460);
insert into department values (	1013,'Service','Union Trust','MANKATO','MN',87461);
insert into department values (	1014,'Customer Representative','307 W. Allegheny Avenue','MANKATO','MN',87462);
insert into department values (	1015,'IT','3415 Olanwood Court, Suite 202','MANKATO','MN',87463);
insert into department values (	1016,'HR','145 Laywers Row','ROCHESTER','MN',87464);
insert into department values (	1017,'Board','1717 Arch Street','MANKATO','MN',87465);
insert into department values (	1018,'Mechanical','200 Pennsylvania','MANKATO','MN',87466);
insert into department values (	1019,'Administration','14714 Main Street','MANKATO','MN',87467);
insert into department values (	1020,'Engineering','13 Federal Street P.O Box 704','MANKATO','MN',87468);
insert into department values (	1021,'Legal','645 Aburn Street, Suite 366','MANKATO','MN',87469);

--dept_branch
insert into dept_branch values (	100,1010);
insert into dept_branch values (	101,1011);
insert into dept_branch values (	102,1012);
insert into dept_branch values (	103,1013);
insert into dept_branch values (	104,1014);
insert into dept_branch values (	105,1015);
insert into dept_branch values (	106,1016);
insert into dept_branch values (	107,1017);
insert into dept_branch values (	108,1018);
insert into dept_branch values (	109,1019);
insert into dept_branch values (	110,1020);
insert into dept_branch values (	111,1021);
--dept_emp
insert into dept_emp values (	1000,1010,'12-May-54','10-May-60');	
insert into dept_emp values (	1000,1010,'12-May-54','10-May-60');	
insert into dept_emp values (	1001,1011,'10-Nov-54','8-Nov-60');	
insert into dept_emp values (	1002,1012,'12-May-55','10-May-61');	
insert into dept_emp values (	1003,1013,'10-Nov-55','8-Nov-61');	
insert into dept_emp values (	1004,1014,'11-May-56','10-May-62');	
insert into dept_emp values (	1005,1015,'9-Nov-56','8-Nov-62');	
insert into dept_emp values (	1006,1016,'11-May-57','10-May-63');	
insert into dept_emp values (	1007,1017,'9-Nov-57','8-Nov-63');	
insert into dept_emp values (	1008,1018,'11-May-58','9-May-64');	
insert into dept_emp values (	1009,1019,'9-Nov-58','7-Nov-64');	
insert into dept_emp values (	1010,1020,'11-May-59','9-May-65');	
insert into dept_emp values (	1011,1021,'12-Jun-59','7-Nov-65');

--dept_mgr
insert into dept_mgr values (	1000,1010,'12-May-54','10-May-60');	
insert into dept_mgr values (	1001,1011,'10-Nov-54','8-Nov-60');	
insert into dept_mgr values (	1002,1012,'12-May-55','10-May-61');	
insert into dept_mgr values (	1003,1013,'10-Nov-55','8-Nov-61');	
insert into dept_mgr values (	1004,1014,'11-May-56','10-May-62');	
insert into dept_mgr values (	1005,1015,'9-Nov-56','8-Nov-62');	
insert into dept_mgr values (	1006,1016,'11-May-57','10-May-63');	
insert into dept_mgr values (	1007,1017,'9-Nov-57','8-Nov-63');	
insert into dept_mgr values (	1008,1018,'11-May-58','9-May-64');	
insert into dept_mgr values (	1009,1019,'9-Nov-58','7-Nov-64');	
insert into dept_mgr values (	1010,1020,'11-May-59','9-May-65');	
insert into dept_mgr values (	1011,1021,'12-Jun-59','7-Nov-65');	


--dept_tables
insert into dept_tables values (	1231,1010,'12-May-54','10-May-60','MN',1010);		
insert into dept_tables values (	1232,1011,'10-Nov-54','8-Nov-60','MN',1011);		
insert into dept_tables values (	1233,1012,'12-May-55','10-May-61','MN',1012);		
insert into dept_tables values (	1234,1013,'10-Nov-55','8-Nov-61','MN',1013);		
insert into dept_tables values (	1235,1014,'11-May-56','10-May-62','MN',1014);		
insert into dept_tables values (	1236,1015,'9-Nov-56','8-Nov-62','MN',1015);		
insert into dept_tables values (	1237,1016,'11-May-57','10-May-63','MN',1016);		
insert into dept_tables values (	1238,1017,'9-Nov-57','8-Nov-63','MN',1017);		
insert into dept_tables values (	1239,1018,'11-May-58','9-May-64','MN',1018);		
insert into dept_tables values (	1240,1019,'9-Nov-58','7-Nov-64','MN',1019);		
insert into dept_tables values (	1241,1020,'11-May-59','9-May-65','MN',1020);		
insert into dept_tables values (	1242,1021,'12-Jun-59','7-Nov-65','MN',1021);	

--INstituion


insert into Institution values (	1800,'Instituion ','LAS VEGAS','NV');
insert into Institution values (	1801,'Wehner, Swaniawski and Runte','CARSON CITY','NV');
insert into Institution values (	1802,'Cormier, Kuhn and Schimmel','CARSON CITY','NV');
insert into Institution values (	1803,'Franecki, Brakus and Reilly','SALEM','OR');
insert into Institution values (	1804,'Abbott, Halvorson and Lesch','SALEM','OR');
insert into Institution values (	1805,'Boyle, Hirthe and Bechtelar','ALOHA','OR');
insert into Institution values (	1806,'Glover-Windler','SALEM','OR');
insert into Institution values (	1807,'Boyer, Berge and Rohan','LINCOLN CITY','OR');
insert into Institution values (	1808,'Adams-Hickle','PHOENIX','AZ');
insert into Institution values (	1809,'West LLC','PHOENIX','AZ');
insert into Institution values (	1810,'Hagenes, Koch and Cruickshank','PHOENIX','AZ');
insert into Institution values (	1811,'Gottlieb LLC','PHOENIX','AZ');

--mINOR
insert into Minor values (	1800,'IT');
insert into Minor values (	1801,'Art');
insert into Minor values (	1802,'Design');
insert into Minor values (	1803,'Math');
insert into Minor values (	1804,'English');
insert into Minor values (	1805,'Spanish');
insert into Minor values (	1806,'Dance');
insert into Minor values (	1807,'Esol');
insert into Minor values (	1808,'Accounting');
insert into Minor values (	1809,'Marketing');
insert into Minor values (	1810,'Finance');
insert into Minor values (	1811,'History');

--MAJOR
insert into MAJOr values (	1800,'IT');
insert into MAJOr values (	1801,'Art');
insert into MAJOr values (	1802,'Design');
insert into MAJOr values (	1803,'Math');
insert into MAJOr values (	1804,'English');
insert into MAJOr values (	1805,'Spanish');
insert into MAJOr values (	1806,'Dance');
insert into MAJOr values (	1807,'Esol');
insert into MAJOr values (	1808,'Accounting');
insert into MAJOr values (	1809,'Marketing');
insert into MAJOr values (	1810,'Finance');
insert into MAJOr values (	1811,'History');

--Eduction_Type

insert into education_type values (	2500,'College');
insert into education_type values (	2501,'Diploma');
insert into education_type values (	2502,'High School');
insert into education_type values (	2503,'Middle School');
insert into education_type values (	2504,'Home School');
insert into education_type values (	2505,'University ');
insert into education_type values (	2506,'tuition');
insert into education_type values (	2507,'Branch ');
insert into education_type values (	2508,'Open School');
insert into education_type values (	2509,'Marketing');
insert into education_type values (	2510,'Finance');
insert into education_type values (	2511,'Training ');

--Employee_Education 
insert into Emp_education values (	1000,1800,'12-May-54','9-May-65',1800,1800,2500,3000,'y');
insert into Emp_education values (	1001,1801,'10-Nov-54','7-Nov-65',1801,1801,2501,3001,'n');
insert into Emp_education values (	1002,1802,'12-May-55','9-May-66',1802,1802,2502,3002,'y');
insert into Emp_education values (	1003,1803,'10-Nov-55','7-Nov-66',1803,1803,2503,3003,'y');
insert into Emp_education values (	1004,1804,'11-May-56','9-May-67',1804,1804,2504,3004,'n');
insert into Emp_education values (	1005,1805,'9-Nov-56','7-Nov-67',1805,1805,2505,3005,'n');
insert into Emp_education values (	1006,1806,'11-May-57','8-May-68',1806,1806,2506,3006,'y');
insert into Emp_education values (	1007,1807,'9-Nov-57','6-Nov-68',1807,1807,2507,3007,'y');
insert into Emp_education values (	1008,1808,'11-May-58','8-May-69',1808,1808,2508,3008,'y');
insert into Emp_education values (	1009,1809,'9-Nov-58','6-Nov-69',1809,1809,2509,3009,'n');
insert into Emp_education values (	1010,1810,'11-May-59','8-May-70',1810,1810,2510,3010,'n');
insert into Emp_education values (	1011,1811,'11-May-60','8-May-71',1811,1811,2511,3011,'n');

--Payroll
insert into payroll values (	1,'12-May-54','9-May-65');
insert into payroll values (	2,'10-Nov-54','7-Nov-65');
insert into payroll values (	3,'12-May-55','9-May-66');
insert into payroll values (	4,'10-Nov-55','7-Nov-66');
insert into payroll values (	5,'11-May-56','9-May-67');
insert into payroll values (	6,'9-Nov-56','7-Nov-67');
insert into payroll values (	7,'11-May-57','8-May-68');
insert into payroll values (	8,'9-Nov-57','6-Nov-68');
insert into payroll values (	9,'11-May-58','8-May-69');
insert into payroll values (	10,'9-Nov-58','6-Nov-69');
insert into payroll values (	11,'11-May-59','8-May-70');
insert into payroll values (	12,'11-May-60','8-May-71');

--Emp_payroll
insert into Emp_payroll values (	1,100000,1000);
insert into Emp_payroll values (	2,100001,1001);
insert into Emp_payroll values (	3,100002,1002);
insert into Emp_payroll values (	4,100003,1003);
insert into Emp_payroll values (	5,21213,1004);
insert into Emp_payroll values (	6,2234,1005);
insert into Emp_payroll values (	7,1123,1006);
insert into Emp_payroll values (	8,4354,1007);
insert into Emp_payroll values (	9,123,1008);
insert into Emp_payroll values (	10,53465,1009);
insert into Emp_payroll values (	11,23,1010);
insert into Emp_payroll values (	12,5645,1011);

--skill

insert into skill values (	1,'Hazard Identification');
insert into skill values (	2,'AQTF compliance');
insert into skill values (	3,'IBM Certified');
insert into skill values (	4,'Knee Surgery');
insert into skill values (	5,'Software Design');
insert into skill values (	6,'CCIM');
insert into skill values (	7,'SDLC');
insert into skill values (	8,'eGRC');
insert into skill values (	9,'VLC');
insert into skill values (	10,'Pro II');
insert into skill values (	11,'BST');
insert into skill values (	12,'Algorithm');

--Emp_Skill

insert into Emp_Skill values (	1000,1,'Begineer ');
insert into Emp_Skill values (	1001,2,'Advanced ');
insert into Emp_Skill values (	1002,3,'Advanced ');
insert into Emp_Skill values (	1003,4,'Begineer ');
insert into Emp_Skill values (	1004,5,'Begineer ');
insert into Emp_Skill values (	1005,6,'Begineer ');
insert into Emp_Skill values (	1006,7,'Advanced ');
insert into Emp_Skill values (	1007,8,'Advanced ');
insert into Emp_Skill values (	1008,9,'Advanced ');
insert into Emp_Skill values (	1009,10,'Advanced ');
insert into Emp_Skill values (	1010,11,'Advanced ');
insert into Emp_Skill values (	1011,12,'Begineer ');

--user_info
insert into  user_info  values (	1000,1,'12-May-54','9-May-65');
insert into  user_info  values (	1001,2,'10-Nov-54','7-Nov-65');
insert into  user_info  values (	1002,3,'12-May-55','9-May-66');
insert into  user_info  values (	1003,4,'10-Nov-55','7-Nov-66');
insert into  user_info  values (	1004,5,'11-May-56','9-May-67');
insert into  user_info  values (	1005,6,'9-Nov-56','7-Nov-67');
insert into  user_info  values (	1006,7,'11-May-57','8-May-68');
insert into  user_info  values (	1007,8,'9-Nov-57','6-Nov-68');
insert into  user_info  values (	1008,9,'11-May-58','8-May-69');

--user_ role
insert into  user_info  values (	1000,1,'12-May-54','9-May-65');
insert into  user_info  values (	1001,2,'10-Nov-54','7-Nov-65');
insert into  user_info  values (	1002,3,'12-May-55','9-May-66');
insert into  user_info  values (	1003,4,'10-Nov-55','7-Nov-66');
insert into  user_info  values (	1004,5,'11-May-56','9-May-67');
insert into  user_info  values (	1005,6,'9-Nov-56','7-Nov-67');
insert into  user_info  values (	1006,7,'11-May-57','8-May-68');
insert into  user_info  values (	1007,8,'9-Nov-57','6-Nov-68');
insert into  user_info  values (	1008,9,'11-May-58','8-May-69');

--relationship
insert into relationship values (	'1','Brother');
insert into relationship values (	'2','spouse');
insert into relationship values (	'3','business');
insert into relationship values (	'4','friend');
insert into relationship values (	'5','Sister');
insert into relationship values (	'6','spouse');
insert into relationship values (	'7','business');
insert into relationship values (	'8','friend');
insert into relationship values (	'9','Brother');
insert into relationship values (	'10','spouse');
insert into relationship values (	'11','professional');
insert into relationship values (	'12','friend');

--Relation

insert into dependents values (	1000,'Stefan','M','12-May-54',119778213,1010,1);
insert into dependents values (	1001,'Donald','M','10-Nov-54',119778213,1011,2);
insert into dependents values (	1002,'Al','F','12-May-55',119778213,1012,3);
insert into dependents values (	1003,'Bruce','F','10-Nov-55',119778213,1013,4);
insert into dependents values (	1004,'Albert','M','11-May-56',119778213,1014,5);
insert into dependents values (	1005,'William C.','F','9-Nov-56',119778213,1015,6);
insert into dependents values (	1006,'Peter','F','11-May-57',119778213,1016,7);
insert into dependents values (	1007,'Patricia A.','M','9-Nov-57',119778213,1017,8);
insert into dependents values (	1008,'James F.','M','11-May-58',119778213,1018,9);
insert into dependents values (	1009,'John C.','M','9-Nov-58',119778213,1019,10);
insert into dependents values (	1010,'Thomas','M','11-May-59',119778213,1020,11);
insert into dependents values (	1011,'Steward','M','12-Jun-59',119778213,1021,12);

--External_Emp_certificate

insert into External_EMP_Certification values (1000,1100,'12-May-54','9-May-65',1200);
insert into  External_EMP_Certification values (	1001,1101,'10-Nov-54','7-Nov-65',1201);
insert into  External_EMP_Certification values (	1002,1102,'12-May-55','9-May-66',1202);
insert into  External_EMP_Certification values (	1003,1103,'10-Nov-55','7-Nov-66',1203);
insert into  External_EMP_Certification values (	1004,1104,'11-May-56','9-May-67',1204);


--External_Emp_Training

insert into  External_EMP_Training values (	1000,1100,'12-May-54','9-May-65',1);
insert into  External_EMP_Training values (	1001,1101,'10-Nov-54','7-Nov-65',2);
insert into  External_EMP_Training values (	1002,1102,'12-May-55','9-May-66',3);
insert into  External_EMP_Training values (	1003,1103,'10-Nov-55','7-Nov-66',4);
insert into  External_EMP_Training values (	1004,1104,'11-May-56','9-May-67',5);

--Internal_EMP_Training

insert into  Internal_EMP_Training values (	1000,1010,'12-May-54','9-May-65',1);
insert into  Internal_EMP_Training values (	1001,1011,'10-Nov-54','7-Nov-65',2);
insert into  Internal_EMP_Training values (	1002,1012,'12-May-55','9-May-66',3);
insert into  Internal_EMP_Training values (	1003,1013,'10-Nov-55','7-Nov-66',4);
insert into  Internal_EMP_Training values (	1004,1014,'11-May-56','9-May-67',5);

--List_Tables
insert into list_Tables values (	1233,'Departmetns');
insert into list_Tables values (	1234,'Customer');
insert into list_Tables values (	1235,'Employee');
insert into list_Tables values (	1236,'Order');
insert into list_Tables values (	1237,'Relationship');
insert into list_Tables values (	1238,'Orrderline');
insert into list_Tables values (	1239,'branch');
insert into list_Tables values (	1240,'salary');
insert into list_Tables values (	1241,'payroll');
insert into list_Tables values (	1242,'inquiry');

-- inquiry
ALTER TABLE inquiry
Alter column start_time nvarchar(20) not null;

ALTER TABLE inquiry
Alter column end_time nvarchar(20) not null;

insert into inquiry values (	1,'9-May-67','12-May-54','9-May-65',12,1000,1);
insert into inquiry values (	2,'7-Nov-67','10-Nov-54','7-Nov-65',123,1001,1);
insert into inquiry values (	3,'8-May-68','12-May-55','9-May-66',1234,1003,1);
insert into inquiry values (	4,'6-Nov-68','10-Nov-55','7-Nov-66',12345,1006,1);
insert into inquiry values (	5,'8-May-69','11-May-56','9-May-67',123456,1023,1);

--order_inquiry

insert into  Order_Inquiry  values (	121,'5-Nov-74','good',100,1,1001,1001);	
insert into  Order_Inquiry  values (	122,'7-May-75','bad',110,2,1002,1003);	
insert into  Order_Inquiry  values (	123,'5-Nov-75','perfect',1005,3,1003,1006);	
insert into Order_Inquiry  values (	124,'6-May-76','stisfactory ',1006,4,1004,1023);	
insert into  Order_Inquiry values (	125,'4-Nov-76','good',1007,5,1005,1000);	

--inquiry_Action

insert into Inquiry_Action  values (		12,1,'good',121);
insert into  Inquiry_Action   values (		11,2,'bad',122);
insert into  Inquiry_Action   values (		124,3,'perfect',123);
insert into  Inquiry_Action   values (		32,4,'stisfactory ',124);
insert into  Inquiry_Action   values (		12,5,'good',125);

--orderrinquiry_action
insert into  orderinquiry_action  values (		13,'3-Nov-81',25600,14700,45,10000,9130,11,1004);	
insert into  orderinquiry_action  values (		14,'5-May-81',26350,15155,48,2000,1826,124,1005);	
insert into  orderinquiry_action  values (		15,'3-Nov-80',25410,35154,6,2560,2337.28,32,1006);	
insert into  orderinquiry_action  values (		16,'5-May-80',35140,556484,98,5000,4565,12,1007);






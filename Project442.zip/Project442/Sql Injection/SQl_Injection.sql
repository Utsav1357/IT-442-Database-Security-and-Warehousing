--Q1) SQL Injection Attack using where clause in employee_position--

 -- run query without parameters--
DECLARE 
    @sql nVARCHAR(MAX),
    @Emp_POS_NO nVARCHAR(MAX);
	
-- run query without parameters--
SET @sql = N'SELECT * FROM Employee_Position';
EXEC sp_executesql @sql;
 
-- run query using parameters(s)
SET @Emp_POS_NO = N'2';
SET @sql = N'SELECT * FROM Employee_Position  WHERE Emp_POS_NO = ' + @Emp_POS_NO;
EXEC sp_executesql @sql;
 
-- run query using parameters(s) with added SQL injection code
SET @Emp_POS_NO = N'2 OR 1 = 1';
SET @sql = N'SELECT * FROM Employee_Position WHERE Emp_POS_NO = ' + @Emp_POS_NO;
EXEC sp_executesql @sql;


--Q2) SQL Injection Attack using union clause Certificate--

Select * from certificate;

DECLARE 
    @sql nVARCHAR(MAX),
    @cert_NO nVARCHAR(MAX);

-- run query without parameters--
SET @sql = N'SELECT * FROM certificate';
EXEC sp_executesql @sql;
 
-- run query using parameters(s)
SET @cert_NO  = N'1';
SET @sql = N'select * FROM certificate WHERE cert_NO = ' + @cert_NO;
EXEC sp_executesql @sql;
 
-- run query using parameters(s) with added SQL injection code
SET @cert_NO = N'1 UNION SELECT Cert_no, Cert_Name+ '' ''  FROM certificate';
SET @sql = N'select * FROM certificate WHERE cert_NO = ' + @cert_NO;
EXEC sp_executesql @sql;


--Q3) SQL injection Prevent in certificate --

Select * from Certificate

DECLARE 
    @sql nVARCHAR(MAX),
    @cert_name nVARCHAR(MAX),
	@PARAMS NVARCHAR(1000);

SET @cert_name = 'Security'
    
SET @PARAMS = '@cert_name NVARCHAR(MAX)'
SET @SQL =N'SELECT * FROM certificate WHERE cert_name= @Cert_name'
    
EXECUTE sp_executesql @SQL ,@PARAMS, @cert_name = @Cert_name

-- testinng for prevention from SQL injection--

SET @cert_name = 'Security OR 1 = 1'  
SET @PARAMS = '@cert_name NVARCHAR(MAX)'
SET @SQL =N'SELECT * FROM certificate WHERE cert_name= @Cert_name'
    
EXECUTE sp_executesql @SQL ,@PARAMS, @cert_name = @Cert_name

--Q4) SQL injection Prevent in Employee_Position --
Select * from Employee_Position

DECLARE 
    @sql nVARCHAR(MAX),
    @description nVARCHAR(MAX),
	@PARAMS NVARCHAR(1000);

SET @description = 'CEO'
    
SET @PARAMS = '@description NVARCHAR(MAX)'
SET @SQL =N'SELECT * FROM employee_position WHERE description= @Description'
    
EXECUTE sp_executesql @SQL ,@PARAMS, @description = @Description

-- testinng for prevention from SQL injection--

SET @description = 'CEO OR 1 = 1'  
SET @PARAMS = '@description NVARCHAR(MAX)'
SET @SQL =N'SELECT * FROM employee_position WHERE description= @Description'
    
EXECUTE sp_executesql @SQL ,@PARAMS, @description = @Description
















--Q4) SQL injection prevent--

--AUDIT TABLES with triggers--

--Q1 put records of all the instert in employee (Aduit Employment Change Enviroment)--

drop table Employee_DepartaureAudit;
drop trigger DepartureDelete;
     
select * into Employee_DepartaureAudit From Employee;

Select * from Employee_DepartaureAudit;

Alter table  Employee_DepartaureAudit  add Username varchar(100);
Alter table  Employee_DepartaureAudit  add DateModified varchar(100);

delete from Employee_DepartaureAudit;


Create trigger DepartureDelete on Employee
for delete
AS 
INSERT INTO Employee_DepartaureAudit(EMPLOYEE_NO,lname, fname,street ,state, city ,zip,status, DOB, Branch_NO, 
Username,DateModified)

Select EMPLOYEE_NO,lname, fname,street ,state, city ,zip,status, DOB, Branch_NO,Suser_name(),GETDATE() 
from deleted;

--test--


insert into EMPLOYEE values(1069,'Adams','Doris','1345 Rice Blvd.','PHOENIX','AZ',85003,1,'	6-May-78',112);
insert into EMPLOYEE values(1068,'Adams','Doris','1345 Rice Blvd.','PHOENIX','AZ',85003,1,'	6-May-78',112);
insert into EMPLOYEE values(1067,'Adams','Doris','1345 Rice Blvd.','PHOENIX','AZ',85003,1,'	6-May-78',112);

dELETE FROM EMPLOYEE WHERE EMPLOYEE_NO = 1069;
dELETE FROM EMPLOYEE WHERE EMPLOYEE_NO = 1067;
dELETE FROM EMPLOYEE WHERE EMPLOYEE_NO = 1068;

Select * from Employee_DepartaureAudit;


--Q2 update the reocrds of all the departments tables(Auditing to store updated record of department)--

drop table Employee_DepartmentAudit
Drop trigger insertDepartment
Drop trigger DepartmentUpdate

Create table Employee_DepartmentAudit(
Dept_NO int NULL,
ID_No int not  Null,
Dept_name varchar(30) NULL,
street varchar(40) NULL,
city varchar(15) NULL,
state varchar(2) NULL,
zip int NULL,
USERNAME VARCHAR(100) NULL,
SYSTEMNAME VARCHAR(100) NULL,
createdOn Varchar(100) null,
constraint deparmentAudit_PK primary key (ID_NO) )

CREATE TRIGGER insertDepartment
ON dbo.department
AFTER insert
AS
Begin
	DECLARE @ID_No int
	Select @ID_No = Dept_NO from inserted


 INSERT INTO Employee_DepartmentAudit(
ID_No ,Dept_name, street ,city ,state ,zip,USERNAME,SYSTEMNAME,createdOn )
 select Dept_NO, Dept_name, street ,city ,state ,zip,SUSER_NAME(),HOST_NAME(), GETDATE()
 from dbo.Department 
 where dbo.department.Dept_NO = @ID_No
 END
 GO


CREATE TRIGGER DepartmentUpdate
ON dbo.department
AFTER update
AS
Begin
	DECLARE @ID_No int
	Select @ID_No = Dept_NO from inserted


 INSERT INTO Employee_DepartmentAudit(
ID_No ,Dept_name, street ,city ,state ,zip,USERNAME,SYSTEMNAME,createdOn )
 select Dept_No,Dept_name, street ,city ,state ,zip,SUSER_NAME(),HOST_NAME(), GETDATE()
 from dbo.Department 
 where dbo.department.Dept_NO = @ID_No
 END
 GO

--test--
update Department
set Dept_name = 'sales'
where dept_no = 1012

Select * from Employee_DepartmentAudit

--Q3 roles update (Audit enviroment for updating the roles of users)--


drop table Role_Audit;
drop trigger updatesRoles;
     
select * into Role_Audit From Roles;

delete from Role_Audit;

Alter table  Role_Audit  add USername varchar(100);
Alter table  Role_Audit  add DateModified varchar(100);

Create trigger UpdatesRoles on Roles
for update
AS 
Insert into Role_Audit(Role_ID, Role_Name ,Username,Datemodified)
Select Role_ID, Role_Name, Suser_name(),GETDATE() 
from deleted;

--test--
update Roles
set Role_name = 'Staff'
where Role_ID ='3';
Select * from Role_Audit

--Delete the infromation frombackorder table Table no 1 (Delete version)--

drop table backorder_Audit;
drop trigger deletebackorder;
     
select * into backorder_Audit From backorder;


delete from backorder_Audit;

Alter table  backorder_Audit  add USername varchar(100);
Alter table  backorder_Audit  add DateModified varchar(100);

Create trigger deletebackorder on backorder
for delete
AS 
Insert into Backorder_Audit(backorder_no, product_no ,bo_qty, bo_date,Username,Datemodified)
Select backorder_no, product_no ,bo_qty, bo_date , Suser_name(),GETDATE() 
from deleted;

--test--
insert into backorder values(	1124,200,290,	'7-May-03	');
delete from backorder WHERE backorder_no = 1124;
 Select * from backorder_Audit
 
 --Insert the infromation from relationship table Table no 2 (delete version)--
 
drop table relationship_Audit;
drop trigger insertRelationship;
     
select * into relationship_Audit From Relationship;

Select * from relationship_Audit

Alter table  relationship_Audit  add Username varchar(100);
Alter table  relationship_Audit  add DateModified varchar(100);

delete from relationship_Audit;

Create trigger insertRelationship on Relationship
for delete 
AS 
Insert into relationship_Audit(Rel_type, Rel_name,Username,Datemodified)
Select Rel_type, Rel_name, Suser_name(),GETDATE() 
from deleted;

--test--
delete from Relationship WHERE Rel_type = 13;
insert into Relationship  values (	'13','friend');

 Select * from relationship_Audit

 --Insert the infromation from skills table Table no 3 (update version)--
 
 drop table Skill_Audit;
drop trigger updateSkills;
     
select * into Skill_Audit From skill;

Select * from Skill_Audit;

Alter table  Skill_Audit  add Username varchar(100);
Alter table  Skill_Audit  add DateModified varchar(100);

delete from Skill_Audit;


Create trigger updateSkills on skill
for update
AS 
Insert into Skill_Audit(Skill_NO, Skill_name,Username,Datemodified)
Select Skill_NO, Skill_name, Suser_name(),GETDATE() 
from deleted;

--test--
update Skill
set Skill_name = 'DataBase'
where Skill_No ='12';
Select * from skill_Audit

 --Insert the infromation from region table Table no 4 (delete version)--

drop table Regions_Audit;
drop trigger deleteRegion;
     
select * into Regions_Audit From regions;

Select * from Regions_Audit;

Alter table  Regions_Audit  add Username varchar(100);
Alter table  Regions_Audit  add DateModified varchar(100);

delete from Regions_Audit;


Create trigger deleteRegion on regions
for delete
AS 
Insert into Regions_Audit(region_no, timezone,Username,Datemodified)
Select region_NO, timezone, Suser_name(),GETDATE() 
from deleted;

--test--
insert into regions values(	7,'Eastern');
delete from regions WHERE region_no =7;

Select * from Regions_Audit;
 
--Insert the infromation from position table Table no 5 (update version)--

use ZeotaV1_C;
drop table position_Audit;
drop trigger UpdatePosition;
     
select * into position_Audit From position;

Select * from position_Audit;

Alter table  position_Audit  add Username varchar(100);
Alter table  position_Audit  add DateModified varchar(100);

delete from position_Audit;


Create trigger UpdatePosition on position
for update
AS 
Insert into position_Audit(position_no, description,Username,Datemodified)
Select position_no, description, Suser_name(),GETDATE() 
from deleted;

--test--
insert into position values(	10,'Accountant');
update position
Set description ='sale manager'
WHERE position_no =10;

Select * from position_Audit;

--Insert the infromation from certificate table Table no 6 (delete version)--


drop table Certificate_Audit;
drop trigger DeleteCertificate;
     
select * into Certificate_Audit From Certificate;

Select * from Certificate_Audit;

Alter table  Certificate_Audit  add Username varchar(100);
Alter table  Certificate_Audit  add DateModified varchar(100);

delete from Certificate_Audit;


Create trigger DeleteCertificate on Certificate
for delete
AS 
Insert into Certificate_Audit(Cert_no, cert_name,Username,Datemodified)
Select Cert_no, cert_name, Suser_name(),GETDATE() 
from deleted;

--test--
insert into Certificate values(	1205,'science');
delete from certificate
where cert_name ='Science'


Select * from Certificate_Audit;

--Insert the infromation from Department_mgr table Table no 7 (delete version)--

drop table DepartmnetMngr_Audit;
drop trigger UpdateDepartmnetMngr;
     
select * into DepartmnetMngr_Audit From Dept_Mgr;

Select * from DepartmnetMngr_Audit;

Alter table  DepartmnetMngr_Audit  add Username varchar(100);
Alter table  DepartmnetMngr_Audit  add DateModified varchar(100);

delete from DepartmnetMngr_Audit;


Create trigger UpdateDepartmnetMngr on Dept_Mgr
for delete
AS 
Insert into DepartmnetMngr_Audit(Emp_no,Dept_NO, Start_date,end_date,Username,Datemodified)
Select Emp_no,Dept_NO, Start_date, end_Date,Suser_name(),GETDATE() 
from deleted;

--test--
insert into dept_mgr values (	1012,1021,'12-Jun-60','7-Nov-65');
delete from Dept_Mgr
where Start_date ='12-Jun-60'


Select * from DepartmnetMngr_Audit;

--Insert the infromation from Department_mgr table Table no 8 (delete version)--


drop table EmpSkill_Audit;
drop trigger deleteEmpSkill;
     
select * into EmpSkill_Audit From Emp_Skill;

Select * from EmpSkill_Audit;

Alter table  EmpSkill_Audit  add Username varchar(100);
Alter table  EmpSkill_Audit  add DateModified varchar(100);

delete from EmpSkill_Audit;


Create trigger deleteEmpSkill on Emp_Skill
for delete
AS 
Insert into EmpSkill_Audit(Emp_no,Skill_NO,level,Username,DateModified)
Select Emp_no,Skill_NO, level,Suser_name(),GETDATE() 
from deleted;

--test--
insert into Emp_Skill values (	1012,12,'master');
delete from Emp_Skill
where level ='master';


Select * from EmpSkill_Audit;

--Insert the infromation from State_capital table Table no 9 (update version)--

drop table StateCapital_Audit;
drop trigger UpdateStateCapital;
     
select * into StateCapital_Audit From State_Capital;

Select * from StateCapital_Audit;

Alter table  StateCapital_Audit  add Username varchar(100);
Alter table  StateCapital_Audit  add DateModified varchar(100);

delete from StateCapital_Audit;


Create trigger UpdateStateCapital on State_Capital
for update
AS 
Insert into StateCapital_Audit(city,state,zip,region_no,Username,DateModified)
Select city,state, zip,region_no,Suser_name(),GETDATE() 
from deleted;

--test--
insert into state_capital values(	'CHARLESTONa','Vermont',25302,6);

Update State_Capital
set zip =000000
where region_no =6;


Select * from StateCapital_Audit;

--Insert the infromation from Company table Table no 10 (update version)--

drop table Company_Audit;
drop trigger UpdateCompany;
     
select * into Company_Audit From Company;

Select * from Company_Audit;

Alter table  Company_Audit  add Username varchar(100);
Alter table  Company_Audit  add DateModified varchar(100);

delete from Company_Audit;


Create trigger UpdateCompany on Company
for update
AS 
Insert into Company_Audit(Comp_NO, Comp_name, Phone#, city,state,zip,Username,DateModified)
Select Comp_NO, Comp_name, Phone#,city,state, zip,Suser_name(),GETDATE() 
from deleted;

--test--
insert into company values(	1113,'Chak',3,'Stewart Sreet','CARSON CITY',89701,'NV');

Update Company
set comp_name ='Gaide'
where State ='NV';
Select * from Company_Audit;







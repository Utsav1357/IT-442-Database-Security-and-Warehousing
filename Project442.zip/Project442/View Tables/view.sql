SELECT dbo.Department.Dept_NO, dbo.Department.Dept_name, dbo.Dept_Branch.Branch_NO, dbo.Dept_Emp.start_date, dbo.Dept_Emp.end_date, dbo.Dept_Tables.Table_ID, dbo.Dept_Tables.Role_ID
FROM     dbo.Department INNER JOIN
                  dbo.Dept_Branch ON dbo.Department.Dept_NO = dbo.Dept_Branch.Dept_NO INNER JOIN
                  dbo.Dept_Emp ON dbo.Department.Dept_NO = dbo.Dept_Emp.Dept_NO INNER JOIN
                  dbo.Dept_Mgr ON dbo.Department.Dept_NO = dbo.Dept_Mgr.Dept_NO AND dbo.Department.Dept_NO = dbo.Dept_Mgr.Dept_NO INNER JOIN
                  dbo.Dept_Tables ON dbo.Department.Dept_NO = dbo.Dept_Tables.dept_no
WHERE  (dbo.Department.Dept_NO > 1012);
--hr--

Create view [V_HR] as 
SELECT dbo.Department.Dept_NO, dbo.Department.Dept_name, dbo.EMPLOYEE.EMPLOYEE_NO, dbo.EMPLOYEE.LNAME, dbo.EMPLOYEE.FNAME, dbo.EMPLOYEE.STREET, dbo.EMPLOYEE.CITY, dbo.EMPLOYEE.STATE, dbo.EMPLOYEE.ZIP, 
                  dbo.EMPLOYEE.STATUS, dbo.regions.region_no
FROM     dbo.Department CROSS JOIN
                  dbo.EMPLOYEE CROSS JOIN
                  dbo.regions;				  
				  
				  
--Sales--

Create view [V_Sales] as
SELECT dbo.CUSTOMER.CUSTOMER_NO, dbo.CUSTOMER.LNAME, dbo.CUSTOMER.FNAME, dbo.INQUIRY.Inquiry_ID, dbo.INQUIRY.Start_time, dbo.INQUIRY.End_time, dbo.Inquiry_Action.Description, dbo.ORDERLINE.ORDERLINE_NO, 
                  dbo.ORDERLINE.QTY, dbo.ORDERLINE.PRODUCT_NO, dbo.ORDERS.ORDER_NO, dbo.ORDERS.EMPLOYEE_NO, dbo.ORDERS.TOTAL_AMT, dbo.return_category.return_code, dbo.return_category.description AS [Return Description], 
                  dbo.RETURNPROD.RETURN_ID, dbo.RETURNPROD.RETR_QTY, dbo.RETURNPROD.DATE_RETURNED, dbo.RETURNPROD.AMOUNT_REFUNDED, dbo.ship_method.Ship_Method_NO, dbo.ship_method.Mthod_name
FROM     dbo.CUSTOMER INNER JOIN
                  dbo.INQUIRY ON dbo.CUSTOMER.CUSTOMER_NO = dbo.INQUIRY.customer_NO INNER JOIN
                  dbo.Inquiry_Action ON dbo.INQUIRY.Inquiry_ID = dbo.Inquiry_Action.Inquiry_ID INNER JOIN
                  dbo.ORDERS ON dbo.CUSTOMER.CUSTOMER_NO = dbo.ORDERS.CUSTOMER_NO INNER JOIN
                  dbo.ORDERLINE ON dbo.ORDERS.ORDER_NO = dbo.ORDERLINE.ORDER_NO INNER JOIN
                  dbo.RETURNPROD ON dbo.ORDERLINE.ORDERLINE_NO = dbo.RETURNPROD.ORDERLINE_NO INNER JOIN
                  dbo.return_category ON dbo.RETURNPROD.RETURN_CODE = dbo.return_category.return_code INNER JOIN
                  dbo.ship_method ON dbo.ORDERS.SHIP_Method_NO = dbo.ship_method.Ship_Method_NO;

--Purchasing--

Create view [V_Purchasing] as
SELECT dbo.VENDOR.VENDOR_NO, dbo.VENDOR.NAME, dbo.VENDOR.STREET, dbo.VENDOR.CITY, dbo.VENDOR.STATE, dbo.VENDOR.ZIP, dbo.VENDOR.TEL_NO, dbo.Return2Vendor.Return_Date, dbo.Return2Vendor.PRODUCT_NO, 
                  dbo.Return2Vendor.QTY, dbo.Return2Vendor.V_Confirmation_No, dbo.Return2Vendor.Amount, dbo.PRODVENDOR.ORDER_DATE, dbo.PRODVENDOR.EXPECTED_RECVD_DATE, dbo.PRODVENDOR.ACTUAL_RECVD_DATE, 
                  dbo.VENDORPRICE.VPRICE, dbo.VENDORPRICE.VPRICE_NO, dbo.VENDORPRICE.DISCOUNT
FROM     dbo.VENDOR INNER JOIN
                  dbo.Return2Vendor ON dbo.VENDOR.VENDOR_NO = dbo.Return2Vendor.VENDOR_NO INNER JOIN
                  dbo.PRODVENDOR ON dbo.VENDOR.VENDOR_NO = dbo.PRODVENDOR.VENDOR_NO INNER JOIN
                  dbo.VENDORPRICE ON dbo.VENDOR.VENDOR_NO = dbo.VENDORPRICE.VENDOR_NO;

--Payroll--
Create view [V_Payroll] as
SELECT dbo.payroll.payroll_NO, dbo.payroll.start_date, dbo.payroll.end_date, dbo.EMP_payroll.amount, dbo.Sales_commission.order_NO, dbo.Sales_commission.Amount AS [Salea comission Amount], dbo.Sales_commission.Comm_date, 
                  dbo.Return_Sales_Commission.Return_ID, dbo.Return_Sales_Commission.Amount AS [Return Sales Cominssion Amount]
FROM     dbo.payroll INNER JOIN
                  dbo.EMP_payroll ON dbo.payroll.payroll_NO = dbo.EMP_payroll.payroll_NO CROSS JOIN
                  dbo.Return_Sales_Commission CROSS JOIN
                  dbo.Sales_commission
				  
				  
--MARKETING--

Create view [V_Marketing]as 
SELECT dbo.PROMOTION.PROMOTION_NO, dbo.PROMOTION.promotion_name, dbo.Prod_Promotion.p_price, dbo.QTYDISCOUNT.MIN_QTY, dbo.QTYDISCOUNT.MAX_QTY, dbo.QTYDISCOUNT.QTYDISCOUNT_NO, 
                  dbo.Vendor_QTYDISCOUNT.D_PRICE, dbo.Vndor_PROMOTION.START_DATE, dbo.Vndor_PROMOTION.END_DATE, dbo.Vndor_PROMOTION.V_Price
FROM     dbo.Vndor_PROMOTION INNER JOIN
                  dbo.PROMOTION INNER JOIN
                  dbo.Prod_Promotion ON dbo.PROMOTION.PROMOTION_NO = dbo.Prod_Promotion.PROMO_ID ON dbo.Vndor_PROMOTION.promo_no = dbo.PROMOTION.PROMOTION_NO CROSS JOIN
                  dbo.Vendor_QTYDISCOUNT INNER JOIN
                  dbo.QTYDISCOUNT ON dbo.Vendor_QTYDISCOUNT.QTYDISCOUNT_NO = dbo.QTYDISCOUNT.QTYDISCOUNT_NO;

--SECUIRTY--

Create view [V_Security]as 
SELECT dbo.User_Info.UserID, dbo.User_Role.Dept_NO, dbo.User_Role.start_date, dbo.User_Role.end_date, dbo.EMPLOYEE.EMPLOYEE_NO, dbo.Employee_Position.Description, dbo.Employee_Position.Postion_no, dbo.User_Info.Emp_NO, 
                  dbo.EMPLOYEE.FNAME, dbo.EMPLOYEE.LNAME
FROM     dbo.User_Info INNER JOIN
                  dbo.User_Role ON dbo.User_Info.UserID = dbo.User_Role.UserID INNER JOIN
                  dbo.EMPLOYEE ON dbo.User_Info.Emp_NO = dbo.EMPLOYEE.EMPLOYEE_NO INNER JOIN
                  dbo.Employee_Position ON dbo.EMPLOYEE.EMPLOYEE_NO = dbo.Employee_Position.employee_no;

--USER MANAGMENT--

Create view [V_User Managment]as
SELECT dbo.User_Role.Dept_NO, dbo.User_Role.UserID, dbo.User_Role.start_date, dbo.User_Role.end_date, dbo.User_Info.Emp_NO, dbo.EMPLOYEE.FNAME, dbo.EMPLOYEE.LNAME, dbo.EMPLOYEE.STREET, dbo.EMPLOYEE.CITY, 
                  dbo.EMPLOYEE.STATE, dbo.EMPLOYEE.ZIP, dbo.EMPLOYEE.STATUS, dbo.Department.Dept_name
FROM     dbo.User_Role INNER JOIN
                  dbo.User_Info ON dbo.User_Role.UserID = dbo.User_Info.UserID INNER JOIN
                  dbo.EMPLOYEE ON dbo.User_Info.Emp_NO = dbo.EMPLOYEE.EMPLOYEE_NO INNER JOIN
                  dbo.Department ON dbo.User_Role.Dept_NO = dbo.Department.Dept_NO;

--Order MANAGMENT--

Create view [V_Order Managment]as
SELECT dbo.PRODUCT.PRODUCT_NO, dbo.PRODUCT.BRAND, dbo.PRODUCT.CLASS, dbo.PRODUCT.PRODUCT_DESCRIPTION, dbo.PRODUCT.UNIT_PRICE, dbo.PRODUCT.UNIT_COST, dbo.PRODUCT.PRODUCT_CATEGORY, 
                  dbo.PRODUCT.AVAIL_DATE, dbo.ORDERLINE.ORDERLINE_NO, dbo.ORDERLINE.ORDER_NO
FROM     dbo.PRODUCT INNER JOIN
                  dbo.ORDERLINE ON dbo.PRODUCT.PRODUCT_NO = dbo.ORDERLINE.PRODUCT_NO INNER JOIN
                  dbo.ORDERS ON dbo.ORDERLINE.ORDER_NO = dbo.ORDERS.ORDER_NO;

--Customer Relation MANAGMENT--
Create view [V_Customer Relation MANAGMENT]as
SELECT dbo.INQUIRY.*, dbo.Inquiry_Action.Description, dbo.INQUIRY_Category.category, dbo.Order_Inquiry.Date_Resolved, dbo.Order_Inquiry.Comments, dbo.Inquiry_Action.Order_Inquiry_ID, dbo.OrderInquiry_Action.Date_Action, 
                  dbo.OrderInquiry_Action.Adj_Price_Amt, dbo.OrderInquiry_Action.Adj_Ship_Amt
FROM     dbo.INQUIRY INNER JOIN
                  dbo.Inquiry_Action ON dbo.INQUIRY.Inquiry_ID = dbo.Inquiry_Action.Inquiry_ID INNER JOIN
                  dbo.INQUIRY_Category ON dbo.INQUIRY.Cat_ID = dbo.INQUIRY_Category.Cat_ID INNER JOIN
                  dbo.Order_Inquiry ON dbo.INQUIRY.Inquiry_ID = dbo.Order_Inquiry.Inquiry_ID AND dbo.Inquiry_Action.Order_Inquiry_ID = dbo.Order_Inquiry.Order_Inquiry_ID INNER JOIN
                  dbo.OrderInquiry_Action ON dbo.Inquiry_Action.IA_ID = dbo.OrderInquiry_Action.IA_ID

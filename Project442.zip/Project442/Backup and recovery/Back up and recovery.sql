-- Backing up Zeotav1_C--

BACKUP DATABASE [ZeotaV1_C] TO  
DISK = N'D:\Fall 2020\Project442\ZeotaV1a_C.bak' 
WITH 
NOFORMAT, 
NOINIT,  
NAME = N'ZeotaV1_C-Full Database Backup', 
SKIP, 
NOREWIND,
NOUNLOAD,  STATS = 10
GO

--Restoring backup database--

USE [master]
RESTORE DATABASE [ZeotaV1_C] 
FROM  DISK = N'D:\Fall 2020\Project442\ZeotaV1a_C.bak' 
WITH  FILE = 1,  
NOUNLOAD,  
STATS = 5

GO

--transition log backup-- (UNDO and REDO logs)

BACKUP LOG [ZeotaV1_C]
TO  DISK = N'D:\Fall 2020\Project442\Transcition_log,bak' 
WITH NOFORMAT, NOINIT, 
NAME = N'ZeotaV1_C-Full Database Backup', 
SKIP, 
NOREWIND, 
NOUNLOAD, 
STATS = 10
GO

